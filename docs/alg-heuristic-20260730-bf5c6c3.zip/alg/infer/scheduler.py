"""企业平台调用的内置算法标准入口。

接口与 ``other_alg`` 算法包保持一致：``init`` 接收设备拓扑 JSON，
``update`` 接收调度快照 JSON 并返回标准输出 JSON。当前仓库包含多种
内置算法，因此 ``update`` 额外接受可选的 ``algorithm`` 参数。
"""

from __future__ import annotations

from typing import Optional

from infer.function import init_framework, update_framework


def init(topo_data: str) -> None:
    """初始化设备拓扑，并清空上一次算法会话。

    参数:
        topo_data: 企业标准 ``AlgInit.Info`` 对象的 JSON 字符串。
    """
    init_framework(topo_data)


def update(tool_json: str, algorithm: Optional[str] = None) -> str:
    """执行一次排程或实时重算，并返回标准 ``AlgOutput`` JSON。

    参数:
        tool_json: 企业标准 update 对象或带 ``Info`` 的日志包装 JSON。
        algorithm: 可选算法名，支持 ``heuristic``、``loadlock-macro``、
            ``nn-saea``、``setrank``、``neuralucb``、``neural``、
            ``e2e-ctq``、``rl``、``milp``。
            同一次 ``init`` 会话的后续 update 必须保持一致。

    返回:
        标准算法输出的 JSON 字符串；包装输入会得到包装输出。
    """
    return update_framework(tool_json, algorithm)
