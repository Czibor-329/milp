"""当前仓库内置调度算法的企业标准接口包。

外部系统应通过 :mod:`infer.scheduler` 调用 ``init`` 和 ``update``。
实际会话状态、算法选择和实时重算逻辑由 ``infer.function`` 维护。
"""

