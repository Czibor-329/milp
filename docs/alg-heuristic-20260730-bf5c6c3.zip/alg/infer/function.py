"""内置调度算法的标准 ``init/update`` 会话实现。

本模块负责解析企业 JSON 外壳、选择内置算法、维护同一设备的实时调度状态，
并把 :class:`RealtimeRescheduler` 的结果转换为稳定的标准输出。HTTP 服务和
独立算法仓库都复用这条边界，避免形成两套外部调用语义。
"""

from __future__ import annotations

import json
import os
import threading
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterator, Mapping, Optional

from src.schedule.realtime import RealtimeRescheduler


JsonObject = Dict[str, Any]
SUPPORTED_ALGORITHMS = frozenset({"heuristic"})
DEFAULT_ALGORITHM = "heuristic"
ALGORITHM_ENVIRONMENT_VARIABLE = "CT_SCHEDULER_ALGORITHM"
PROJECT_ROOT = Path(__file__).resolve().parents[1]
NEURAL_MODEL_PATH = PROJECT_ROOT / "src" / "schedule" / "neural_policy.npz"
E2E_CTQ_MODEL_PATH = PROJECT_ROOT / "src" / "schedule" / "e2e_ctq_policy.npz"
SETRANK_MODEL_PATH = PROJECT_ROOT / "src" / "schedule" / "heuristic_config_policy.npz"
NEURAL_UCB_MODEL_PATH = PROJECT_ROOT / "src" / "schedule" / "neural_ucb_policy.npz"
RL_MODEL_PATH = PROJECT_ROOT / "results" / "models" / "bc_policy_rl.pt"

_SESSION_LOCK = threading.RLock()
_TOPOLOGY: Optional[JsonObject] = None
_RUNTIME: Optional[RealtimeRescheduler] = None
_ACTIVE_ALGORITHM: Optional[str] = None
_SEEN_MATERIAL_IDS: set[Any] = set()
_NEURAL_POLICY: Any = None
_E2E_CTQ_POLICY: Any = None
_SETRANK_POLICY: Any = None
_NEURAL_UCB_POLICY: Any = None
_RL_POLICY: Any = None


@dataclass(frozen=True)
class PlatformEnvelope:
    """解析后的平台输入及其可选日志包装信息。"""

    payload: JsonObject
    wrapped: bool = False
    request_id: int = 0
    sim_time: Any = None
    time: Optional[str] = None


def _read_json_object(text: str) -> JsonObject:
    """读取第一个 JSON object，兼容 BOM、前导空白和尾部日志。"""
    if not isinstance(text, str):
        raise TypeError("标准算法输入必须是 JSON 字符串")
    stripped = text.lstrip("\ufeff \t\r\n")
    if not stripped:
        raise ValueError("标准算法输入 JSON 为空")
    value, _ = json.JSONDecoder().raw_decode(stripped)
    if not isinstance(value, dict):
        raise ValueError("标准算法输入 JSON 顶层必须是 object")
    return dict(value)


def _parse_info(value: Any) -> JsonObject:
    """把包装结构的 ``Info`` 字段解析为标准对象。"""
    if isinstance(value, Mapping):
        return dict(value)
    if isinstance(value, str):
        return _read_json_object(value)
    raise ValueError("标准算法包装输入的 Info 必须是 object 或 JSON 字符串")


def _unwrap_platform_json(text: str) -> PlatformEnvelope:
    """解析裸标准 JSON 或包含 ``Info`` 的平台日志包装 JSON。"""
    value = _read_json_object(text)
    if "Info" in value and any(
        key in value for key in ("Time", "Describe", "SimTime")
    ):
        payload = _parse_info(value.get("Info"))
        return PlatformEnvelope(
            payload=payload,
            wrapped=True,
            request_id=int(value.get("RequestID", payload.get("RequestID", 0)) or 0),
            sim_time=value.get("SimTime"),
            time=None if value.get("Time") is None else str(value.get("Time")),
        )
    return PlatformEnvelope(
        payload=value,
        request_id=int(value.get("RequestID", 0) or 0),
    )


def _wrap_standard_output(
    output: Mapping[str, Any],
    envelope: PlatformEnvelope,
) -> JsonObject:
    """按照输入包装形式生成裸输出或 ``AlgOutput`` 日志对象。"""
    if not envelope.wrapped:
        return dict(output)
    return {
        "Time": envelope.time
        or datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
        "Describe": "AlgOutput",
        "SimTime": 0 if envelope.sim_time is None else envelope.sim_time,
        "RequestID": envelope.request_id,
        "Info": dict(output),
    }


def _normalize_algorithm(algorithm: Optional[str], payload: Mapping[str, Any]) -> str:
    """解析算法参数，并拒绝精简部署包不包含的其他策略。"""
    selected = str(
        algorithm
        or payload.get("Algorithm")
        or os.environ.get(ALGORITHM_ENVIRONMENT_VARIABLE)
        or DEFAULT_ALGORITHM
    ).strip().lower()
    if selected not in SUPPORTED_ALGORITHMS:
        supported = "、".join(sorted(SUPPORTED_ALGORITHMS))
        raise ValueError(f"algorithm 只支持 {supported}，收到 {selected or '<empty>'}")
    return selected


def _load_policy(algorithm: str) -> Any:
    """按需加载 SetRank、Neural 或 RL 策略；其他算法不需要模型。"""
    global _NEURAL_POLICY, _E2E_CTQ_POLICY, _SETRANK_POLICY, _NEURAL_UCB_POLICY, _RL_POLICY
    if algorithm == "setrank":
        if _SETRANK_POLICY is None:
            if not SETRANK_MODEL_PATH.is_file():
                raise ValueError(f"SetRank-PIAC 模型不存在：{SETRANK_MODEL_PATH}")
            from src.schedule.heuristic_tuning import load_setrank_policy

            _SETRANK_POLICY = load_setrank_policy(SETRANK_MODEL_PATH)
        return _SETRANK_POLICY
    if algorithm == "neuralucb":
        if _NEURAL_UCB_POLICY is None:
            if not NEURAL_UCB_MODEL_PATH.is_file():
                raise ValueError(
                    f"Safe NeuralUCB 模型不存在：{NEURAL_UCB_MODEL_PATH}"
                )
            from src.schedule.neural_ucb import load_neural_ucb_policy

            _NEURAL_UCB_POLICY = load_neural_ucb_policy(NEURAL_UCB_MODEL_PATH)
        return _NEURAL_UCB_POLICY
    if algorithm == "neural":
        if _NEURAL_POLICY is None:
            if not NEURAL_MODEL_PATH.is_file():
                raise ValueError(f"Neural 模型不存在：{NEURAL_MODEL_PATH}")
            from src.schedule.neural import load_neural_policy

            _NEURAL_POLICY = load_neural_policy(NEURAL_MODEL_PATH)
        return _NEURAL_POLICY
    if algorithm == "e2e-ctq":
        if _E2E_CTQ_POLICY is None:
            if not E2E_CTQ_MODEL_PATH.is_file():
                raise ValueError(
                    f"端到端资源流模型不存在：{E2E_CTQ_MODEL_PATH}"
                )
            from src.schedule.e2e_ctq import load_e2e_ctq_policy

            _E2E_CTQ_POLICY = load_e2e_ctq_policy(E2E_CTQ_MODEL_PATH)
        return _E2E_CTQ_POLICY
    if algorithm == "rl":
        if _RL_POLICY is None:
            if not RL_MODEL_PATH.is_file():
                raise ValueError(f"RL 模型不存在：{RL_MODEL_PATH}")
            from src.schedule.policy import load_policy

            _RL_POLICY = load_policy(RL_MODEL_PATH)
        return _RL_POLICY
    return None


def _runtime_options(payload: Mapping[str, Any]) -> JsonObject:
    """读取可选 ``AlgorithmOptions``，并转换为调度器构造参数。"""
    raw_options = payload.get("AlgorithmOptions")
    options = dict(raw_options) if isinstance(raw_options, Mapping) else {}

    def optional_positive(name: str) -> Optional[float]:
        """把缺失或非正目标转换为禁用状态。"""
        raw_value = options.get(name)
        if raw_value is None or raw_value == "":
            return None
        value = float(raw_value)
        return value if value > 0.0 else None

    return {
        "loadlock_manager_mode": options.get("loadLockManager"),
        "loadlock_macro_search_seconds": float(
            4.0
            if options.get("loadLockMacroSearchSeconds") is None
            else options["loadLockMacroSearchSeconds"]
        ),
        "loadlock_macro_rollouts": int(
            96
            if options.get("loadLockMacroRollouts") is None
            else options["loadLockMacroRollouts"]
        ),
        "nn_saea_search_seconds": float(
            4.0
            if options.get("nnSAEASearchSeconds") is None
            else options["nnSAEASearchSeconds"]
        ),
        "nn_saea_rollouts": int(
            64
            if options.get("nnSAEARollouts") is None
            else options["nnSAEARollouts"]
        ),
        "rl_search_seconds": float(options.get("rlSearchSeconds") or 4.0),
        "rl_rollouts": int(options.get("rlRollouts") or 256),
        "rl_temperature": float(options.get("rlTemperature") or 0.7),
        "setrank_top_k": int(options.get("setrankTopK") or 3),
        "neural_ucb_top_k": int(options.get("neuralUCBTopK") or 2),
        "neural_ucb_exploration": (
            None
            if options.get("neuralUCBExploration") is None
            else float(options["neuralUCBExploration"])
        ),
        "milp_time_limit": float(options.get("milpTimeLimit") or 120.0),
        "residency_guard_seconds": float(
            options.get("residencyGuardSeconds") or 0.0
        ),
        "maximum_robot_holding_seconds": optional_positive(
            "maximumRobotHoldingSeconds"
        ),
        "maximum_system_residence_cv": optional_positive(
            "maximumSystemResidenceCv"
        ),
        "seed": int(options.get("seed") or 0),
    }


def _material_ids(payload: Mapping[str, Any]) -> set[Any]:
    """返回 update 中具有稳定 ID 的全部物料编号。"""
    return {
        material.get("ID")
        for material in (payload.get("Materials") or [])
        if isinstance(material, Mapping) and material.get("ID") is not None
    }


def _incoming_update(
    payload: Mapping[str, Any],
    new_material_ids: set[Any],
) -> JsonObject:
    """从企业全量 update 中提取本轮首次出现的 Job 和物料。

    ``RealtimeRescheduler`` 已经保存旧任务及物理状态，因此重算输入只应包含
    新增任务。企业接口仍可继续发送全量 PJob/CJob 快照。
    """
    incoming = deepcopy(dict(payload))
    incoming["Materials"] = [
        deepcopy(dict(material))
        for material in (payload.get("Materials") or [])
        if isinstance(material, Mapping)
        and material.get("ID") in new_material_ids
    ]

    process_jobs: list[JsonObject] = []
    new_process_job_names: set[str] = set()
    for raw_job in payload.get("ProcessJobs") or []:
        if not isinstance(raw_job, Mapping):
            continue
        material_ids = [
            material_id
            for material_id in (raw_job.get("MatList") or [])
            if material_id in new_material_ids
        ]
        if not material_ids:
            continue
        job = deepcopy(dict(raw_job))
        job["MatList"] = material_ids
        process_jobs.append(job)
        if job.get("JobName"):
            new_process_job_names.add(str(job["JobName"]))
    incoming["ProcessJobs"] = process_jobs

    control_jobs: list[JsonObject] = []
    for raw_job in payload.get("ControlJobs") or []:
        if not isinstance(raw_job, Mapping):
            continue
        process_job_names = [
            str(name)
            for name in (raw_job.get("PJobNameList") or [])
            if str(name) in new_process_job_names
        ]
        if not process_job_names:
            continue
        job = deepcopy(dict(raw_job))
        job["PJobNameList"] = process_job_names
        job["MaterialCount"] = sum(
            len(process_job.get("MatList") or [])
            for process_job in process_jobs
            if str(process_job.get("JobName") or "") in process_job_names
        )
        control_jobs.append(job)
    incoming["ControlJobs"] = control_jobs
    incoming["MoveStates"] = []
    incoming["RemoveList"] = []
    return incoming


def _apply_move_states(
    runtime: RealtimeRescheduler,
    payload: Mapping[str, Any],
) -> None:
    """把企业 update 携带的 Move 开始/完成通知应用到当前会话。"""
    for raw_notification in payload.get("MoveStates") or []:
        if not isinstance(raw_notification, Mapping):
            raise ValueError("MoveStates 中的每一项都必须是 object")
        runtime.update_move_state(dict(raw_notification), snapshot=False)


def _release_removed_materials(
    runtime: RealtimeRescheduler,
    current_material_ids: set[Any],
) -> set[Any]:
    """按全量 update 中已消失的物料释放完成 LoadPort 占位。

    企业重算快照会移除已经卸载的成品。内部实时调度器也必须同步裁剪这些
    晶圆，否则已完成批次仍会参与下一轮 PM 负载基线。
    """
    removed_material_ids = _SEEN_MATERIAL_IDS - current_material_ids
    if not removed_material_ids or _TOPOLOGY is None:
        return set()
    load_port_names = [
        str(name)
        for name, station in (_TOPOLOGY.get("Stations") or {}).items()
        if isinstance(station, Mapping)
        and str(station.get("Type") or "").lower() == "loadport"
    ]
    released_ids, _ = runtime.release_completed_load_ports(load_port_names)
    missing = removed_material_ids - released_ids
    if missing:
        released_ids.update(runtime.release_materials(missing))
    return set(removed_material_ids)


def _release_reused_source_slots(
    runtime: RealtimeRescheduler,
    payload: Mapping[str, Any],
    new_material_ids: set[Any],
) -> set[Any]:
    """在新任务复用同一 LoadPort 槽位前卸载旧片。

    部分平台全量快照会暂时保留已结束 PJob 的 Material 行，但同时把同一
    LoadPort 槽位分配给新片。新分配代表旧片已经离机，应以槽位复用事实
    清理内部状态，避免两片同时占用一个物理槽。
    """
    reused_slots = {
        (
            str(material.get("CurrentModuleName") or ""),
            int(material.get("SlotID") or 0),
        )
        for material in (payload.get("Materials") or [])
        if isinstance(material, Mapping)
        and material.get("ID") in new_material_ids
        and str(material.get("CurrentModuleName") or "")
        and int(material.get("SlotID") or 0) > 0
    }
    if not reused_slots:
        return set()
    released: set[Any] = set()
    state = runtime.state
    for station_name, slot_id in reused_slots:
        station = state.stations.get(station_name)
        slot = station.slots.get(slot_id) if station is not None else None
        if (
            slot is not None
            and slot.material is not None
            and slot.material.material_id not in new_material_ids
        ):
            released.add(slot.material.material_id)
    runtime.release_materials(released)
    return released


def _standard_output(runtime: RealtimeRescheduler) -> JsonObject:
    """把当前有效计划转换为企业标准输出结构。"""
    job_names = sorted({
        str(wafer.pjob_name)
        for wafer in runtime.problem.wafers
        if str(wafer.pjob_name)
    })
    material_process_modules = {
        str(wafer.mat_id): list(dict.fromkeys(
            stage.chamber
            for stage in wafer.stages
            if stage.stage_type == "process" and stage.chamber
        ))
        for wafer in runtime.problem.wafers
    }
    return {
        "MoveList": runtime.current_plan,
        "Feedback": [],
        "JobList": [{"JobName": name} for name in job_names],
        "DummyReturnInfo": {},
        "MatIntoPM": material_process_modules,
    }


@contextmanager
def session() -> Iterator[None]:
    """独占全局标准算法会话，供并发服务完整执行一次多轮计划。"""
    with _SESSION_LOCK:
        yield


def get_last_strategy_diagnostics() -> JsonObject:
    """返回最近一次内置算法排程的诊断副本，供服务展示使用。"""
    with _SESSION_LOCK:
        if _RUNTIME is None:
            return {}
        return _RUNTIME.last_strategy_diagnostics


def init_framework(topo_data: str) -> None:
    """解析并保存设备拓扑，同时清空上一次实时调度会话。"""
    global _TOPOLOGY, _RUNTIME, _ACTIVE_ALGORITHM, _SEEN_MATERIAL_IDS
    envelope = _unwrap_platform_json(topo_data)
    topology = envelope.payload
    if not isinstance(topology.get("Robots"), Mapping):
        raise ValueError("init 缺少 Robots 对象")
    if not isinstance(topology.get("Stations"), Mapping):
        raise ValueError("init 缺少 Stations 对象")
    with _SESSION_LOCK:
        _TOPOLOGY = deepcopy(topology)
        _RUNTIME = None
        _ACTIVE_ALGORITHM = None
        _SEEN_MATERIAL_IDS = set()


def update_framework(tool_json: str, algorithm: Optional[str] = None) -> str:
    """执行首排或实时重算，并返回与输入包装形式一致的 JSON 字符串。"""
    global _RUNTIME, _ACTIVE_ALGORITHM, _SEEN_MATERIAL_IDS
    envelope = _unwrap_platform_json(tool_json)
    payload = envelope.payload
    selected_algorithm = _normalize_algorithm(algorithm, payload)

    with _SESSION_LOCK:
        if _TOPOLOGY is None:
            raise RuntimeError("必须先调用 init(topo_data) 再调用 update(tool_json)")
        if (
            _ACTIVE_ALGORITHM is not None
            and selected_algorithm != _ACTIVE_ALGORITHM
        ):
            raise ValueError(
                "同一次 init 会话不能切换 algorithm；"
                f"当前为 {_ACTIVE_ALGORITHM}，收到 {selected_algorithm}"
            )

        current_material_ids = _material_ids(payload)
        if _RUNTIME is None:
            _RUNTIME = RealtimeRescheduler(
                _TOPOLOGY,
                payload,
                payload,
                strategy=selected_algorithm,
                policy=_load_policy(selected_algorithm),
                **_runtime_options(payload),
            )
            _ACTIVE_ALGORITHM = selected_algorithm
            _SEEN_MATERIAL_IDS = set(current_material_ids)
        else:
            if selected_algorithm == "milp":
                raise ValueError("MILP 算法只支持首次排程，不能执行连续 update")
            _apply_move_states(_RUNTIME, payload)
            released_material_ids = _release_removed_materials(
                _RUNTIME,
                current_material_ids,
            )
            new_material_ids = current_material_ids - _SEEN_MATERIAL_IDS
            if not new_material_ids:
                raise ValueError("连续 update 必须包含至少一个首次出现的 Material")
            released_material_ids.update(_release_reused_source_slots(
                _RUNTIME,
                payload,
                new_material_ids,
            ))
            incoming = _incoming_update(payload, new_material_ids)
            current_time = float(payload.get("CurrentTime") or 0.0)
            _RUNTIME.recompute(
                incoming,
                current_time,
                cutoff_time=current_time,
                schedule_start_time=current_time,
                released_material_ids=released_material_ids,
                reason="standard_update",
            )
            _SEEN_MATERIAL_IDS.update(new_material_ids)

        output = _standard_output(_RUNTIME)
        wrapped_output = _wrap_standard_output(output, envelope)
        return json.dumps(wrapped_output, ensure_ascii=False)
