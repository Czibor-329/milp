"""把解析后的清洁配置展开为各调度策略共享的固定约束。"""

from typing import Optional, List, Tuple, Dict
from src.parse.model import Problem, Wafer
from dataclasses import dataclass

# --------------------------------------------------------------------------- #
# 清洁展开（决策4）：pre/post/wac 折成固定占腔事件（无片、无搬运），不进 0/1。
#   dummy 清洁已由 synthesize_dummy_routes 合成为 dummy 晶圆，随 task.pjobs 正常流转。
# --------------------------------------------------------------------------- #
@dataclass
class _Clean:
    chamber: str
    slot: int
    dur: float
    recipe: str
    task: str
    kind: str                          # 'pre' / 'post' / 'wac'
    before: Optional[Tuple[int, int]] = None   # 须早于此 (wid, j) 的占腔
    after: Optional[Tuple[int, int]] = None    # 须晚于此 (wid, j) 的占腔
    pjob_name: str = ""
    sequence_before: float = 0.0       # 同一边界内排在本事件前的清洁总时长
    sequence_total: float = 0.0        # 同一边界全部清洁的总时长


def _is_dummy_wafer(w: Wafer) -> bool:
    """合成的 dummy 清洁片：pjob 名 dummy_<PM>（synthesize_dummy_routes）或 route 名含 _dummy_。"""
    return w.pjob_name.startswith("dummy_") or "_dummy_" in w.route_name


def _occ_by_chamber(
    wafers: List[Wafer],
) -> Tuple[Dict[str, List[Tuple[int, int]]], Dict[str, List[Tuple[int, int]]]]:
    """每个 process 腔按 wid 升序的占用 (wid, j)，真实片 / 合成 dummy 片分开归组。"""
    by_ch: Dict[str, List[Tuple[int, int]]] = {}
    dummy_by_ch: Dict[str, List[Tuple[int, int]]] = {}
    for w in wafers:
        dst = dummy_by_ch if _is_dummy_wafer(w) else by_ch
        for j, s in enumerate(w.stages):
            if s.stage_type == "process" and s.chamber:
                dst.setdefault(s.chamber, []).append((w.wid, j))
    for grp in (by_ch, dummy_by_ch):
        for occ in grp.values():
            occ.sort()
    return by_ch, dummy_by_ch


def _pjob_runs(
    wmap: Dict[int, Wafer], occ: List[Tuple[int, int]],
) -> List[List[Tuple[int, int]]]:
    """按 CJob/PJob 归组，并让同一 CJob 的高优先级 PJob 排在前面。"""
    grouped: Dict[Tuple[str, str], List[Tuple[int, int]]] = {}
    for o in occ:
        wafer = wmap[o[0]]
        grouped.setdefault((wafer.cjob_id, wafer.pjob_name), []).append(o)
    cjob_first_wid: Dict[str, int] = {}
    for (cjob_id, _), run in grouped.items():
        first_wid = min(item[0] for item in run)
        cjob_first_wid[cjob_id] = min(
            cjob_first_wid.get(cjob_id, first_wid),
            first_wid,
        )
    runs = list(grouped.values())
    for run in runs:
        run.sort()
    runs.sort(key=lambda run: (
        cjob_first_wid.get(wmap[run[0][0]].cjob_id, run[0][0]),
        int(wmap[run[0][0]].pjob_priority),
        run[0][0],
    ))
    return runs


def _dummy_order_pairs(
    task: Problem, wafers: List[Wafer],
) -> List[Tuple[Tuple[int, int], Tuple[int, int]]]:
    """dummy 清洁段与产品段的同腔定序对 (after, before)：occ_end(after) ≤ occ_start(before)。

    每个 dummy 段（一个 dummy pjob 在一个 PM 上的占用）夹在其所属产品的 job 边界之间：
    前一 job 的所有占用 → dummy 段首片，dummy 段末片 → 本 job 的所有占用，
    实现每腔 d(P1) → P1 → d(P2) → P2。所属产品由 Problem.dummy_owner 提供（缺失则不加约束）。
    """
    owner = getattr(task, "dummy_owner", {}) or {}
    if not owner:
        return []
    wmap = {w.wid: w for w in wafers}
    by_ch, dummy_by_ch = _occ_by_chamber(wafers)
    pairs: List[Tuple[Tuple[int, int], Tuple[int, int]]] = []
    for c, docc in dummy_by_ch.items():
        occ = by_ch.get(c)
        if not occ:
            continue
        runs = _pjob_runs(wmap, occ)
        run_idx = {wmap[run[0][0]].pjob_name: i for i, run in enumerate(runs)}
        for drun in _pjob_runs(wmap, docc):
            i = run_idx.get(owner.get(wmap[drun[0][0]].pjob_name, ""))
            if i is None:
                continue
            if i > 0:
                for o in runs[i - 1]:            # 前一 job 全部占用 → dummy 段首片
                    pairs.append((o, drun[0]))
            for o in runs[i]:                    # dummy 段末片 → 本 job 全部占用
                pairs.append((drun[-1], o))
    return pairs


def _matching_specs(specs, pjob_name: str, chamber: str):
    """返回指定 PJob/PM 的清洁规格，优先使用带 owner 的新格式。"""
    exact = [
        spec
        for spec in specs
        if spec.pjob_name == pjob_name and chamber in spec.visits
    ]
    if exact:
        return exact
    return [
        spec
        for spec in specs
        if not spec.pjob_name and chamber in spec.visits
    ]


def _clean_specs(task: Problem, wafers: List[Wafer]) -> List[_Clean]:
    """按 PJob、PM 和触发顺序展开无片清洁事件。

    同一边界严格按 ``Wac → PostClean → PreClean`` 串行，既不重叠也不合并。
    Wac 计数在每个 PJob/PM 内独立重置；PreClean 只在所属 PJob 首片进该 PM
    前触发，PostClean 只在所属 PJob 末片离开该 PM 后触发。DummyClean 本身
    仍由合成 dummy wafer 表示，DummyWac 排在每片 dummy 后。
    """
    wmap = {w.wid: w for w in wafers}
    by_chamber, dummy_by_chamber = _occ_by_chamber(wafers)
    dummy_owner = getattr(task, "dummy_owner", {}) or {}
    boundaries: Dict[
        Tuple[str, Optional[Tuple[int, int]], Optional[Tuple[int, int]]],
        List[_Clean],
    ] = {}

    def add(
        chamber: str,
        slot: int,
        duration: float,
        recipe: str,
        task_name: str,
        kind: str,
        pjob_name: str,
        *,
        after: Optional[Tuple[int, int]],
        before: Optional[Tuple[int, int]],
    ) -> None:
        """向一个物理边界追加清洁，最终统一计算串行偏移。"""
        if duration <= 0:
            return
        key = (chamber, after, before)
        boundaries.setdefault(key, []).append(_Clean(
            chamber,
            slot,
            float(duration),
            recipe,
            task_name,
            kind,
            before=before,
            after=after,
            pjob_name=pjob_name,
        ))

    for chamber, occupations in by_chamber.items():
        if not occupations:
            continue
        runs = _pjob_runs(wmap, occupations)
        run_by_pjob = {
            wmap[run[0][0]].pjob_name: run
            for run in runs
        }
        dummy_runs = _pjob_runs(wmap, dummy_by_chamber.get(chamber, []))
        dummy_by_product = {
            dummy_owner.get(wmap[run[0][0]].pjob_name, ""): run
            for run in dummy_runs
            if dummy_owner.get(wmap[run[0][0]].pjob_name, "")
        }

        for run_index, run in enumerate(runs):
            pjob_name = wmap[run[0][0]].pjob_name
            slot = wmap[run[0][0]].stages[run[0][1]].slot
            own_dummy = dummy_by_product.get(pjob_name)
            previous_product = runs[run_index - 1][-1] if run_index > 0 else None
            pre_after = own_dummy[-1] if own_dummy else previous_product

            for spec in _matching_specs(task.pre_clean, pjob_name, chamber):
                add(
                    chamber,
                    slot,
                    spec.time,
                    spec.recipe,
                    spec.task,
                    "pre",
                    pjob_name,
                    after=pre_after,
                    before=run[0],
                )

            stage = wmap[run[0][0]].stages[run[0][1]]
            trigger = int(stage.clean_trigger)
            trigger_indexes = (
                range(trigger - 1, len(run), trigger)
                if trigger > 0 and float(stage.clean_time) > 0
                else ()
            )
            for trigger_index in trigger_indexes:
                after = run[trigger_index]
                if trigger_index + 1 < len(run):
                    before = run[trigger_index + 1]
                elif run_index + 1 < len(runs):
                    next_pjob = wmap[runs[run_index + 1][0][0]].pjob_name
                    next_dummy = dummy_by_product.get(next_pjob)
                    before = next_dummy[0] if next_dummy else runs[run_index + 1][0]
                else:
                    before = None
                add(
                    chamber,
                    slot,
                    stage.clean_time,
                    stage.clean_recipe,
                    "",
                    "wac",
                    pjob_name,
                    after=after,
                    before=before,
                )

            next_before = None
            if run_index + 1 < len(runs):
                next_pjob = wmap[runs[run_index + 1][0][0]].pjob_name
                next_dummy = dummy_by_product.get(next_pjob)
                next_before = next_dummy[0] if next_dummy else runs[run_index + 1][0]
            for spec in _matching_specs(task.post_clean, pjob_name, chamber):
                add(
                    chamber,
                    slot,
                    spec.time,
                    spec.recipe,
                    spec.task,
                    "post",
                    pjob_name,
                    after=run[-1],
                    before=next_before,
                )

        for dummy_run in dummy_runs:
            dummy_pjob = wmap[dummy_run[0][0]].pjob_name
            product_pjob = dummy_owner.get(dummy_pjob, "")
            product_run = run_by_pjob.get(product_pjob)
            if product_run is None:
                continue
            slot = wmap[dummy_run[0][0]].stages[dummy_run[0][1]].slot
            for spec in _matching_specs(task.dummy_wac, product_pjob, chamber):
                for dummy_index, dummy_occupation in enumerate(dummy_run):
                    before = (
                        dummy_run[dummy_index + 1]
                        if dummy_index + 1 < len(dummy_run)
                        else product_run[0]
                    )
                    add(
                        chamber,
                        slot,
                        spec.time,
                        spec.recipe,
                        spec.task,
                        "dummy_wac",
                        product_pjob,
                        after=dummy_occupation,
                        before=before,
                    )

    kind_order = {"wac": 0, "dummy_wac": 0, "post": 1, "pre": 2}
    cleans: List[_Clean] = []
    for events in boundaries.values():
        events.sort(key=lambda event: kind_order.get(event.kind, 99))
        total = sum(event.dur for event in events)
        elapsed = 0.0
        for event in events:
            event.sequence_before = elapsed
            event.sequence_total = total
            elapsed += event.dur
            cleans.append(event)
    return cleans
