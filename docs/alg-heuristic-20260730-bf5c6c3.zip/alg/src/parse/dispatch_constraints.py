"""生成所有调度算法共享的晶圆发片偏序。

本模块只描述“谁必须先离开 LoadPort”，不决定 LoadLock、Robot 或加工腔顺序。
约束包括 PJob 内按 Material ID 的 FIFO、同一 CJob 内不同 PJob 优先级之间
的整批发片边界，以及 NormalLot CJob 之间的优先级边界；相同优先级的
PJob/CJob 不互相阻塞，可以并发调度。
"""

from __future__ import annotations

from collections import defaultdict
from typing import Dict, Iterable, Tuple

from src.parse.model import Wafer


NORMAL_LOT_JOB_TYPE = 0


def _material_order(wafer: Wafer) -> tuple[int, int]:
    """返回 PJob 内稳定的 Material ID 顺序键。"""
    return int(wafer.mat_id), int(wafer.wid)


def release_predecessors(
    wafers: Iterable[Wafer],
    *,
    include_released: bool = False,
) -> Dict[int, Tuple[int, ...]]:
    """返回每片未发晶圆在离开 LoadPort 前必须已发出的晶圆。

    参数:
        wafers: 当前问题中的晶圆集合。
        include_released: 是否把已经离开过 LoadPort 的续排晶圆纳入 PJob 内链。

    返回:
        ``wid -> predecessor wids``。同一 PJob 内按 Material ID 串成 FIFO；
        同一 CJob 内，低优先级 PJob 的首片还会等待所有更高优先级 PJob 的
        末片离开 LoadPort。NormalLot 中低优先级 CJob 的每个 PJob 首片还会
        等待所有更高优先级 CJob 的晶圆离开 LoadPort。优先级数值越小越高，
        相同优先级不建立跨 PJob 或跨 CJob 边。
    """
    eligible = [
        wafer
        for wafer in wafers
        if include_released or not wafer.already_released
    ]
    by_pjob: dict[tuple[str, str], list[Wafer]] = defaultdict(list)
    for wafer in eligible:
        by_pjob[(wafer.cjob_id, wafer.pjob_name)].append(wafer)
    for rows in by_pjob.values():
        rows.sort(key=_material_order)

    predecessors: dict[int, set[int]] = defaultdict(set)
    for rows in by_pjob.values():
        for previous, current in zip(rows, rows[1:]):
            predecessors[int(current.wid)].add(int(previous.wid))

    pjobs_by_cjob: dict[str, list[list[Wafer]]] = defaultdict(list)
    for rows in by_pjob.values():
        if rows:
            pjobs_by_cjob[rows[0].cjob_id].append(rows)
    for pjob_groups in pjobs_by_cjob.values():
        pjob_groups.sort(
            key=lambda rows: (
                int(rows[0].pjob_priority),
                min(int(wafer.wid) for wafer in rows),
            )
        )
        for rows in pjob_groups:
            current_priority = int(rows[0].pjob_priority)
            first_wid = int(rows[0].wid)
            for higher_rows in pjob_groups:
                if int(higher_rows[0].pjob_priority) >= current_priority:
                    continue
                predecessors[first_wid].add(int(higher_rows[-1].wid))

    # NormalLot 的 CJob.Priority 是跨盒发片硬边界。给低优先级 CJob 中每个
    # PJob 的首片加边，避免同盒另一 PJob 绕过边界；高优先级盒内只需等待
    # 每个 PJob 的末片，因为 PJob 内 FIFO 已保证此前晶圆都已发出。
    normal_cjobs: dict[str, list[list[Wafer]]] = {}
    for cjob_id, pjob_groups in pjobs_by_cjob.items():
        if (
            cjob_id
            and pjob_groups
            and int(pjob_groups[0][0].cjob_job_type) == NORMAL_LOT_JOB_TYPE
        ):
            normal_cjobs[cjob_id] = pjob_groups
    for current_groups in normal_cjobs.values():
        current_priority = int(current_groups[0][0].cjob_priority)
        current_heads = [
            int(rows[0].wid)
            for rows in current_groups
            if rows
        ]
        higher_tails = {
            int(rows[-1].wid)
            for higher_groups in normal_cjobs.values()
            if int(higher_groups[0][0].cjob_priority) < current_priority
            for rows in higher_groups
            if rows
        }
        for current_head in current_heads:
            predecessors[current_head].update(higher_tails)

    return {
        wid: tuple(sorted(blockers))
        for wid, blockers in predecessors.items()
        if blockers
    }


def completion_predecessors(
    wafers: Iterable[Wafer],
) -> Dict[int, Tuple[int, ...]]:
    """返回发片前必须已经完成加工的跨 CJob 前驱晶圆。

    ``dispatch_after`` 保存实时插单形成的 CJob 完成边界。当前晶圆只有在
    列出的 CJob 所有残余晶圆到达终点后才能离开 LoadPort。
    """
    rows = list(wafers)
    by_cjob: dict[str, list[int]] = defaultdict(list)
    for wafer in rows:
        if wafer.cjob_id:
            by_cjob[wafer.cjob_id].append(int(wafer.wid))
    predecessors: Dict[int, Tuple[int, ...]] = {}
    for wafer in rows:
        if wafer.already_released:
            continue
        blockers = {
            blocker_wid
            for blocker_cjob in wafer.dispatch_after
            for blocker_wid in by_cjob.get(blocker_cjob, [])
        }
        if blockers:
            predecessors[int(wafer.wid)] = tuple(sorted(blockers))
    return predecessors


__all__ = ["completion_predecessors", "release_predecessors"]
