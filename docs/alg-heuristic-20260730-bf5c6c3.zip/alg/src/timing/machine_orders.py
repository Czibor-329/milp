"""把 Machine 的离散搬运决策转换为精确定时层使用的固定资源顺序。

Machine 负责根据物理状态暴露合法候选并记录策略选中的 ``RobotAction``；本模块
只提取腔室、机器人和 LoadLock 的离散先后关系，不采用 Machine 前向推演得到的
时间。加工腔原子换片会还原成“先出后进”的保守 Robot 顺序，随后由
``solve_timing`` 在驻留等全部时间约束可行时重新提升为原子换片。
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from typing import Dict, Mapping, Sequence, Tuple

from src.parse.model import Problem, Wafer
from src.validation.machine import RobotAction
from src.validation.move_fields import SWAP_MOVE

from ._common import SKIP_TYPES


Visit = Tuple[int, int]
Resource = Tuple[str, int]


@dataclass
class MachineResourceOrders:
    """固定腔室、机器人和 LoadLock 顺序的定时输入。"""

    chambers: Dict[Resource, list[Visit]]
    robots: Dict[str, list[Visit]]
    ll_seq: Dict[str, list[Visit]] = field(default_factory=dict)
    process_swaps: list[Tuple[Visit, Visit, str]] = field(default_factory=list)


def _resource(problem: Problem, wafer: Wafer, stage_index: int) -> Resource | None:
    """返回工序占用的物理资源；源、汇和跳过型站点不进入腔室顺序。"""
    stage = wafer.stages[stage_index]
    if stage.stage_type == "sink" or (
        stage.stage_type == "source" and not wafer.already_released
    ):
        return None
    chamber = problem.chambers.get(stage.chamber)
    if chamber is None or str(chamber.type).lower() in SKIP_TYPES:
        return None
    return stage.chamber, int(stage.slot)


def _swap_partner(action: RobotAction) -> tuple[object, int] | None:
    """从动作预览中读取被 SwapMove 换出的物料及其当前工序。"""
    for move in action.move_preview:
        if int(move.get("MoveType", -1)) != SWAP_MOVE:
            continue
        material_ids = tuple(move.get("RecvMatList") or ())
        stage_ids = tuple(move.get("RecvMatStepIDList") or ())
        if material_ids and stage_ids:
            return material_ids[0], int(stage_ids[0])
    return None


def _append_once(
    sequence: list[Visit],
    visit: Visit,
    seen: set[Visit],
) -> None:
    """按首次出现顺序追加一次逻辑搬运 hop。"""
    if visit in seen:
        return
    sequence.append(visit)
    seen.add(visit)


def resource_orders_from_machine_actions(
    problem: Problem,
    actions: Sequence[RobotAction],
) -> tuple[Problem, MachineResourceOrders]:
    """复制问题并把 Machine 动作轨迹转换为 ``solve_timing`` 的资源顺序。

    返回的 ``Problem`` 会写入 Machine 实际选择的目标腔室和槽位，原问题保持
    不变。对于 PM 双臂换片，Robot 顺序记录为保守的“出片 hop、入片 hop”；
    定时层只有在完整差分约束图可行时才会重新合并换片。
    """
    selected_problem = deepcopy(problem)
    wafer_by_id = {
        int(wafer.wid): wafer for wafer in selected_problem.wafers
    }
    wafer_by_material = {
        wafer.mat_id: wafer for wafer in selected_problem.wafers
    }
    chambers: Dict[Resource, list[Visit]] = {}
    robots: Dict[str, list[Visit]] = {}
    loadlocks: Dict[str, list[Visit]] = {}
    seen_robot_hops: set[Visit] = set()
    seen_visits: set[Visit] = set()

    # 实时续排的裁剪后首工序已经占用物理资源，必须成为对应资源顺序的首项。
    for wafer in selected_problem.wafers:
        if not wafer.already_released:
            continue
        visit = (int(wafer.wid), 0)
        resource = _resource(selected_problem, wafer, 0)
        if resource is None:
            continue
        chambers.setdefault(resource, []).append(visit)
        seen_visits.add(visit)
        chamber = selected_problem.chambers[resource[0]]
        if str(chamber.type).lower() == "loadlock":
            loadlocks.setdefault(resource[0], []).append(visit)

    for action in actions:
        incoming_wafer = wafer_by_id[int(action.wafer_id)]
        incoming_hop = (int(incoming_wafer.wid), int(action.stage_index))
        destination_stage_index = int(action.stage_index) + 1
        destination_stage = incoming_wafer.stages[destination_stage_index]
        destination_stage.chamber = str(action.destination_station)
        destination_stage.slot = int(action.destination_slot) - 1
        if destination_stage.stage_type == "loadlock":
            selected_chamber = selected_problem.chambers.get(
                destination_stage.chamber
            )
            if selected_chamber is not None:
                duration = (
                    selected_chamber.pump_time
                    if destination_stage.ll_type == "entry"
                    else selected_chamber.vent_time
                )
                destination_stage.proc = float(duration or 0.0)

        partner = _swap_partner(action)
        partner_hop: Visit | None = None
        partner_wafer: Wafer | None = None
        if partner is not None:
            partner_material, partner_stage_index = partner
            partner_wafer = wafer_by_material.get(partner_material)
            if partner_wafer is not None:
                partner_hop = (
                    int(partner_wafer.wid),
                    int(partner_stage_index),
                )

        robot_sequence = robots.setdefault(str(action.robot), [])
        is_process_swap = (
            partner_hop is not None
            and partner_wafer is not None
            and destination_stage.stage_type == "process"
            and partner_wafer.stages[partner_hop[1]].stage_type == "process"
        )
        if is_process_swap:
            # 入片可能已在上一个 PM 的换片动作中被取到 Robot 手上；此时同一
            # 逻辑 hop 已经登记在较早位置。把当前 PM 的出片 hop 插到它前面，
            # 保留该位置供定时层整体 JIT 右移。若把入片 hop 删除并挪到当前
            # 动作末尾，会越过上游 PM 的下一次入片，制造资源顺序正环。
            if incoming_hop in seen_robot_hops:
                incoming_index = robot_sequence.index(incoming_hop)
                if partner_hop not in seen_robot_hops:
                    robot_sequence.insert(incoming_index, partner_hop)
                    seen_robot_hops.add(partner_hop)
            else:
                _append_once(robot_sequence, partner_hop, seen_robot_hops)
                _append_once(robot_sequence, incoming_hop, seen_robot_hops)
        else:
            _append_once(robot_sequence, incoming_hop, seen_robot_hops)
            if partner_hop is not None:
                _append_once(robot_sequence, partner_hop, seen_robot_hops)

        destination_visit = (
            int(incoming_wafer.wid),
            destination_stage_index,
        )
        destination_resource = _resource(
            selected_problem,
            incoming_wafer,
            destination_stage_index,
        )
        if (
            destination_resource is not None
            and destination_visit not in seen_visits
        ):
            chambers.setdefault(destination_resource, []).append(
                destination_visit
            )
            seen_visits.add(destination_visit)
            chamber = selected_problem.chambers[destination_resource[0]]
            if str(chamber.type).lower() == "loadlock":
                loadlocks.setdefault(
                    destination_resource[0],
                    [],
                ).append(destination_visit)

    return selected_problem, MachineResourceOrders(
        chambers=chambers,
        robots=robots,
        ll_seq=loadlocks,
    )
