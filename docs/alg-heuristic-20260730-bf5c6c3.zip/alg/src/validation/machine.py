"""面向调度策略的整机抽象。

本模块把物理状态、机器人搬运候选、增量定时和 MoveList 生成收敛到
``Machine``。调度策略只读取不可变快照和搬运意图，并返回选中的
``action_id``；开关门、机器人转位、LoadLock 压力转换和加工事件均由
Machine 自动生成。

当前实现使用“投影式排程”语义：提交一个搬运意图后，物料在规划状态中
投影到该意图及其自动加工完成后的状态，同时各资源保留绝对释放时间。
因此多个 Robot 仍可在同一排程起点并行工作，而策略无需维护事件日历。
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Callable, Dict, Mapping, Optional, Protocol, Sequence, Tuple

from src.parse.clean_constraints import _matching_specs
from src.parse.dispatch_constraints import release_predecessors
from src.parse.model import Durations, Problem, Stage, Wafer
from src.validation.move_fields import (
    COMPLETE_MOVE,
    PICK_MOVE,
    PLACE_MOVE,
    PREPARE_MOVE,
    PRE_PREPARE_MOVE,
    PRE_TRANS_MOVE,
    PROCESS_MOVE,
    SWAP_MOVE,
)
from src.validation.state import (
    ATMOSPHERE,
    VACUUM,
    DoorState,
    LoadLockState,
    MachineState,
    MaterialState,
    SlotPhase,
    is_doorless_station,
)


TIME_TOLERANCE = 1e-6
FIRST_SLOT_ID = 1
RELATED_ACTION_PLACE = 0
RELATED_ACTION_PICK = 1
RELATED_ACTION_SWAP = 2
RELATED_ROBOT_ATMOSPHERE = 0
RELATED_ROBOT_VACUUM = 1
DEFAULT_ROBOT_SLOT = 1
MAXIMUM_DECISIONS = 1_000_000


def _freeze(value: Any) -> Any:
    """递归复制并冻结公开视图，阻止策略修改 Machine 内部数据。"""
    if isinstance(value, Mapping):
        return MappingProxyType({
            key: _freeze(item)
            for key, item in value.items()
        })
    if isinstance(value, (list, tuple, set, frozenset)):
        return tuple(_freeze(item) for item in value)
    return deepcopy(value)


def _thaw(value: Any) -> Any:
    """把公开只读预览还原成 MoveList 需要的可变列表结构。"""
    if isinstance(value, Mapping):
        return {key: _thaw(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_thaw(item) for item in value]
    return deepcopy(value)


def _delay_moves(moves: Sequence[dict], delay: float) -> None:
    """把一组尚未提交的 Move 整体右移，保持内部间隔和结束顺序不变。"""
    if delay <= TIME_TOLERANCE:
        return
    for move in moves:
        move["StartTime"] = float(move["StartTime"]) + delay
        move["EndTime"] = float(move["EndTime"]) + delay


@dataclass(frozen=True)
class MaterialView:
    """供策略读取的单片物料位置和路线进度。"""

    material_id: Any
    pjob_name: str
    step_id: Optional[int]
    location: str
    slot_id: int
    phase: str
    ready_at: float


@dataclass(frozen=True)
class StationView:
    """供策略读取的站点物理摘要。"""

    name: str
    station_type: str
    door: str
    environment: Optional[str]
    ready_at: float
    slots: Mapping[int, Optional[Any]]


@dataclass(frozen=True)
class RobotView:
    """供策略读取的机器人指向、手槽和释放时间。"""

    name: str
    position: Optional[str]
    ready_at: float
    hands: Mapping[int, Optional[Any]]


@dataclass(frozen=True)
class MachineSnapshot:
    """调度策略可见的不可变整机快照。"""

    revision: int
    time: float
    materials: Mapping[Any, MaterialView]
    stations: Mapping[str, StationView]
    robots: Mapping[str, RobotView]
    active_moves: Tuple[Mapping[str, Any], ...]
    completed_action_count: int


@dataclass(frozen=True)
class RobotAction:
    """一个可由策略选择的完整机器人搬运意图。

    ``earliest_start`` 是不考虑目标端等待的逻辑使能时间，供策略判断候选；
    ``move_preview`` 可在不改变完成时刻的前提下采用更晚的 JIT 物理起点。
    """

    revision: int
    action_id: str
    kind: str
    robot: str
    material_ids: Tuple[Any, ...]
    source_station: Optional[str]
    source_slot: Optional[int]
    destination_station: str
    destination_slot: int
    robot_slots: Tuple[int, ...]
    earliest_start: float
    finish_time: float
    move_preview: Tuple[Mapping[str, Any], ...]
    wafer_id: int
    stage_index: int
    flow_kind: str = "internal"
    residency_deadline: Optional[float] = None
    projected_ready_time: float = 0.0


@dataclass(frozen=True)
class MachineRunResult:
    """Machine 完成一次策略运行后的稳定结果。"""

    moves: Tuple[Mapping[str, Any], ...]
    makespan: float
    action_count: int
    snapshot: MachineSnapshot
    actions: Tuple[RobotAction, ...] = ()


class MachineSelector(Protocol):
    """调度策略的最小协议。"""

    def choose(
        self,
        state: MachineSnapshot,
        actions: Sequence[RobotAction],
    ) -> str:
        """从当前候选集合返回一个 ``action_id``。"""


class StaleRobotActionError(RuntimeError):
    """提交了来自旧 Machine revision 的动作。"""


class UnknownRobotActionError(KeyError):
    """提交了当前候选集合中不存在的动作。"""


class MachineDeadlockError(RuntimeError):
    """仍有未完成物料，但 Machine 无法生成合法机器人动作。"""


class Machine:
    """统一管理设备物理语义、增量定时、状态投影和 MoveList。

    参数:
        task: 已解析的设备拓扑与任务。
        init_data: 初始接口快照或现有 ``MachineState``。
        current_time: 本轮排程的绝对起点。
        initial_move_id: 新生成 MoveID 的前一个值。
        allow_loadlock_exchange: 是否向策略暴露同门反向交换候选。

    调度策略不应修改 ``state``，也不应自行生成门、压力或加工 Move。
    """

    def __init__(
        self,
        task: Problem,
        init_data: "Optional[Mapping[str, Any] | MachineState]" = None,
        *,
        current_time: float = 0.0,
        initial_move_id: int = 0,
        allow_loadlock_exchange: bool = True,
    ) -> None:
        self.task = task
        self.state = MachineState.from_sources(task, init_data)
        self.current_time = float(current_time)
        self._initial_state = self.state.clone()
        self._durations = Durations(task)
        self._wafer_by_material = {wafer.mat_id: wafer for wafer in task.wafers}
        self._moves: list[dict] = []
        self._committed_actions: list[RobotAction] = []
        self._active_moves: Dict[int, dict] = {}
        self._revision = 0
        self._next_move_id = int(initial_move_id) + 1
        self._committed_action_count = 0
        self._current_actions: Dict[str, RobotAction] = {}
        self._replay: Any = None
        self._process_visits: Dict[tuple[str, str, int], int] = {}
        self._release_predecessors: Dict[int, Tuple[int, ...]] = {}
        self._remaining_process_visits: Dict[tuple[str, str], int] = {}
        self._process_job_predecessors: Dict[tuple[str, str], str] = {}
        self._pre_cleaned: set[tuple[str, str]] = set()
        self._post_cleaned: set[tuple[str, str]] = set()
        self._allow_loadlock_exchange = bool(allow_loadlock_exchange)
        self._refresh_job_constraints()
        self._apply_runtime_availability()
        self._schedule_pending_services()

    @property
    def revision(self) -> int:
        """返回当前候选版本。"""
        return self._revision

    @property
    def action_count(self) -> int:
        """返回当前计划已经提交的搬运意图数量。"""
        return self._committed_action_count

    def get_state(self) -> MachineSnapshot:
        """返回当前投影状态的不可变快照。"""
        material_views: Dict[Any, MaterialView] = {}
        station_views: Dict[str, StationView] = {}
        for station_name, station in sorted(self.state.stations.items()):
            slot_materials: Dict[int, Optional[Any]] = {}
            for slot_id, slot in sorted(station.slots.items()):
                material = slot.material
                slot_materials[slot_id] = (
                    material.material_id if material is not None else None
                )
                if material is not None:
                    material_views[material.material_id] = MaterialView(
                        material_id=material.material_id,
                        pjob_name=material.pjob_name,
                        step_id=(
                            int(material.step_id)
                            if isinstance(material.step_id, int)
                            else None
                        ),
                        location=station_name,
                        slot_id=slot_id,
                        phase=slot.phase.value,
                        ready_at=float(slot.busy_until),
                    )
            station_views[station_name] = StationView(
                name=station_name,
                station_type=station.station_type,
                door=station.door.value,
                environment=(
                    station.environment
                    if isinstance(station, LoadLockState)
                    else None
                ),
                ready_at=max(
                    float(station.door_busy_until),
                    float(station.transfer_busy_until),
                    float(station.environment_busy_until),
                    *(float(slot.busy_until) for slot in station.slots.values()),
                ),
                slots=MappingProxyType(slot_materials),
            )

        robot_views: Dict[str, RobotView] = {}
        for robot_name, robot in sorted(self.state.robots.items()):
            hands = {
                slot_id: (
                    material.material_id if material is not None else None
                )
                for slot_id, material in sorted(robot.hands.items())
            }
            for slot_id, material in robot.hands.items():
                if material is None:
                    continue
                material_views[material.material_id] = MaterialView(
                    material_id=material.material_id,
                    pjob_name=material.pjob_name,
                    step_id=(
                        int(material.step_id)
                        if isinstance(material.step_id, int)
                        else None
                    ),
                    location=robot_name,
                    slot_id=slot_id,
                    phase="held",
                    ready_at=float(robot.busy_until),
                )
            robot_views[robot_name] = RobotView(
                name=robot_name,
                position=robot.position,
                ready_at=float(robot.busy_until),
                hands=MappingProxyType(hands),
            )
        return MachineSnapshot(
            revision=self._revision,
            time=self.current_time,
            materials=MappingProxyType(material_views),
            stations=MappingProxyType(station_views),
            robots=MappingProxyType(robot_views),
            active_moves=tuple(
                _freeze(move)
                for _, move in sorted(self._active_moves.items())
            ),
            completed_action_count=self._committed_action_count,
        )

    def get_robot_actions(self) -> Tuple[RobotAction, ...]:
        """返回合法搬运意图、策略使能时间及 JIT 物理动作预览。"""
        actions: list[RobotAction] = []
        locations = self._material_locations()
        for material_id, wafer in sorted(
            self._wafer_by_material.items(),
            key=lambda item: int(item[1].wid),
        ):
            location = locations.get(material_id)
            if location is None:
                continue
            location_kind, owner_name, slot_id, material, phase = location
            stage_index = self._stage_index(wafer, material, owner_name)
            if stage_index >= len(wafer.stages) - 1:
                continue
            if location_kind == "station" and phase is not SlotPhase.COMPLETED:
                continue
            if (
                location_kind == "station"
                and stage_index == 0
                and not wafer.already_released
                and self._release_is_blocked(wafer.wid, locations)
            ):
                continue

            robot_name = str(wafer.transports[stage_index])
            robot = self.state.resolve_robot(robot_name)
            if robot is None:
                continue
            if location_kind == "robot" and owner_name != robot.name:
                continue
            if (
                location_kind == "station"
                and any(
                    held_material is not None
                    for held_material in robot.hands.values()
                )
            ):
                # 双臂只用于原子换片，不允许把两个独立搬运事务同时缓存到手上。
                # 否则策略可能连续 Pick 两片，再连续 Place 两片，绕开 SwapMove。
                continue
            source_station = (
                owner_name if location_kind == "station" else robot.position
            )
            source_slot = slot_id if location_kind == "station" else None
            following = wafer.stages[stage_index + 1]
            destinations = (
                [str(following.chamber)]
                if (
                    following.stage_type == "process"
                    and self._fixed_process_destination_required(
                        wafer,
                        following,
                    )
                )
                else list(dict.fromkeys(
                    following.cands or [following.chamber]
                ))
            )
            for destination in destinations:
                if (
                    following.stage_type == "process"
                    and self._process_job_boundary_blocked(
                        wafer.pjob_name,
                        str(destination),
                    )
                ):
                    continue
                target_slot_id = int(following.slot) + FIRST_SLOT_ID
                target = self.state.stations.get(str(destination))
                if target is None:
                    continue
                target_slot = target.slots.get(target_slot_id)
                if target_slot is None:
                    continue
                if robot.scope and (
                    (source_station and source_station not in robot.scope)
                    or destination not in robot.scope
                ):
                    continue
                robot_slot = (
                    slot_id
                    if location_kind == "robot"
                    else self._empty_robot_slot(robot.hands)
                )
                if robot_slot is None:
                    continue
                swap_material: Optional[MaterialState] = None
                receive_robot_slot: Optional[int] = None
                if target_slot.material is not None:
                    if (
                        not robot.can_swap
                        or target_slot.phase is not SlotPhase.COMPLETED
                    ):
                        continue
                    outgoing_wafer = self._wafer_by_material.get(
                        target_slot.material.material_id
                    )
                    if outgoing_wafer is None:
                        continue
                    outgoing_stage = self._stage_index(
                        outgoing_wafer,
                        target_slot.material,
                        str(destination),
                    )
                    if (
                        outgoing_stage >= len(outgoing_wafer.transports)
                        or outgoing_wafer.transports[outgoing_stage] != robot.name
                    ):
                        continue
                    if self._periodic_clean_due_stage(
                        target_slot.material,
                        str(destination),
                    ) is not None:
                        # 下一片离腔即触发清洁时禁止补片；先把旧片送往下游，
                        # 待 PM 空腔清洁完成后再允许新片进入。
                        continue
                    if (
                        following.stage_type == "process"
                        and (
                            self._pre_clean_required(
                                wafer.pjob_name,
                                str(destination),
                            )
                            or self._departure_requires_empty_clean(
                                outgoing_wafer,
                                outgoing_stage,
                                str(destination),
                            )
                        )
                    ):
                        # PJob 边界清洁要求空腔，不能用 Swap 把前一 PJob 末片
                        # 与后一 PJob 首片原子交换。
                        continue
                    receive_robot_slot = next(
                        (
                            hand_slot
                            for hand_slot, hand_material in sorted(robot.hands.items())
                            if hand_slot != int(robot_slot) and hand_material is None
                        ),
                        None,
                    )
                    if receive_robot_slot is None:
                        continue
                    swap_material = target_slot.material
                defer_loadlock_service = (
                    swap_material is None
                    and isinstance(target, LoadLockState)
                    and float(following.proc) > TIME_TOLERANCE
                    and any(
                        other_slot_id != target_slot_id
                        and other_slot.material is not None
                        for other_slot_id, other_slot in target.slots.items()
                    )
                )
                action = self._preview_transfer(
                    wafer=wafer,
                    stage_index=stage_index,
                    robot_name=robot.name,
                    robot_slot=int(robot_slot),
                    material=material,
                    source_station=source_station,
                    source_slot=source_slot,
                    destination_station=str(destination),
                    destination_slot=target_slot_id,
                    already_held=location_kind == "robot",
                    swap_material=swap_material,
                    receive_robot_slot=receive_robot_slot,
                    exchange_material=None,
                    exchange_slot=None,
                    defer_loadlock_service=defer_loadlock_service,
                )
                if action is not None:
                    actions.append(action)
                if swap_material is not None:
                    continue
                exchange_partner = (
                    self._loadlock_exchange_partner(
                        wafer=wafer,
                        stage_index=stage_index,
                        robot_name=robot.name,
                        destination=target,
                        destination_slot=target_slot_id,
                    )
                    if self._allow_loadlock_exchange
                    else None
                )
                if exchange_partner is None:
                    continue
                exchange_slot, exchange_material = exchange_partner
                if self._material_waits_for_pending_clean(exchange_material):
                    # 下一目标 PM 即将或正在清洁时，不借 LoadLock exchange
                    # 把待加工片提前取到 Robot 手上；让它继续停在 LoadLock。
                    continue
                exchange_receive_robot_slot = (
                    next(
                        (
                            hand_slot
                            for hand_slot, hand_material in sorted(
                                robot.hands.items()
                            )
                            if (
                                hand_slot != int(robot_slot)
                                and hand_material is None
                            )
                        ),
                        None,
                    )
                    if robot.can_swap
                    else None
                )
                if robot.can_swap and exchange_receive_robot_slot is None:
                    continue
                exchange_action = self._preview_transfer(
                    wafer=wafer,
                    stage_index=stage_index,
                    robot_name=robot.name,
                    robot_slot=int(robot_slot),
                    material=material,
                    source_station=source_station,
                    source_slot=source_slot,
                    destination_station=str(destination),
                    destination_slot=target_slot_id,
                    already_held=location_kind == "robot",
                    swap_material=None,
                    receive_robot_slot=exchange_receive_robot_slot,
                    exchange_material=exchange_material,
                    exchange_slot=exchange_slot,
                    defer_loadlock_service=False,
                )
                if exchange_action is not None:
                    actions.append(exchange_action)
        actions.sort(
            key=lambda action: (
                action.earliest_start,
                action.finish_time,
                action.robot,
                action.wafer_id,
                action.destination_station,
                action.destination_slot,
            )
        )
        self._current_actions = {action.action_id: action for action in actions}
        return tuple(actions)

    def apply_robot_action(
        self,
        action_id: str,
        *,
        expected_revision: Optional[int] = None,
    ) -> RobotAction:
        """原子提交当前候选中的一个搬运意图。"""
        if expected_revision is not None and expected_revision != self._revision:
            raise StaleRobotActionError(
                f"动作版本过期：expected={expected_revision}, current={self._revision}"
            )
        normalized_action_id = str(action_id)
        revision_prefix = normalized_action_id.split(":", 1)[0]
        if revision_prefix.startswith("r"):
            try:
                action_revision = int(revision_prefix[1:])
            except ValueError:
                action_revision = self._revision
            if action_revision != self._revision:
                raise StaleRobotActionError(
                    f"动作版本过期：action={action_revision}, current={self._revision}"
                )
        action = self._current_actions.get(normalized_action_id)
        if action is None:
            self.get_robot_actions()
            action = self._current_actions.get(normalized_action_id)
        if action is None:
            raise UnknownRobotActionError(normalized_action_id)
        if action.revision != self._revision:
            raise StaleRobotActionError(
                f"动作版本过期：action={action.revision}, current={self._revision}"
            )

        clean_end = self._schedule_action_pre_clean(action)
        committed_moves = []
        for preview in action.move_preview:
            move = _thaw(preview)
            move["MoveID"] = self._next_move_id
            self._next_move_id += 1
            committed_moves.append(move)
        if clean_end is not None and committed_moves:
            first_start = min(
                float(move.get("StartTime") or self.current_time)
                for move in committed_moves
            )
            _delay_moves(committed_moves, max(0.0, clean_end - first_start))
        self._moves.extend(committed_moves)
        self._committed_actions.append(action)
        self._apply_projected_action(action, committed_moves)
        self._schedule_periodic_cleaning(action, committed_moves)
        self._committed_action_count += 1
        self._revision += 1
        self._current_actions = {}
        return action

    def run(
        self,
        selector: "MachineSelector | Callable[[MachineSnapshot, Sequence[RobotAction]], str]",
        *,
        maximum_decisions: int = MAXIMUM_DECISIONS,
    ) -> MachineRunResult:
        """反复调用策略直至所有物料到达 Route 终点。"""
        initial_action_count = len(self._committed_actions)
        for _ in range(maximum_decisions):
            if self._is_done():
                self._close_orphan_doors()
                moves = self.export_movelist()
                makespan = max(
                    (float(move.get("EndTime") or 0.0) for move in moves),
                    default=self.current_time,
                )
                return MachineRunResult(
                    moves=tuple(MappingProxyType(deepcopy(move)) for move in moves),
                    makespan=makespan,
                    action_count=self._committed_action_count,
                    snapshot=self.get_state(),
                    actions=tuple(
                        self._committed_actions[initial_action_count:]
                    ),
                )
            actions = self.get_robot_actions()
            if not actions:
                raise MachineDeadlockError(self._deadlock_message())
            snapshot = self.get_state()
            choose = getattr(selector, "choose", None)
            action_id = (
                choose(snapshot, actions)
                if callable(choose)
                else selector(snapshot, actions)  # type: ignore[misc,operator]
            )
            self.apply_robot_action(
                str(action_id),
                expected_revision=snapshot.revision,
            )
        raise RuntimeError(f"Machine 超过最大决策次数 {maximum_decisions}")

    def export_movelist(self) -> list[dict]:
        """返回按统一时间轴排序、MoveID 稳定的 MoveList 副本。"""
        return [
            deepcopy(move)
            for move in sorted(
                self._moves,
                key=lambda move: (
                    float(move.get("StartTime") or 0.0),
                    int(move.get("MoveID") or 0),
                ),
            )
        ]

    def update_move_state(
        self,
        notification: Mapping[str, Any],
        *,
        snapshot: bool = True,
    ) -> Optional[MachineSnapshot]:
        """接收真实 Move 开始/结束通知并更新 Machine 的现场状态。

        第一次通知到达时，Machine 使用本代初始状态和已导出的 MoveList 创建
        兼容回放器。之后的重算可以直接保留其中 Running 的原子 Move。
        """
        from src.validation.replay import MoveStateReplay

        if self._replay is None:
            self._replay = MoveStateReplay(
                self.task,
                self.export_movelist(),
                self._initial_state,
            )
            self._replay.current_time = self.current_time
        self._replay.update_move_state(notification, snapshot=False)
        self.state = self._replay.state.clone()
        self.current_time = float(self._replay.current_time)
        self._active_moves = {
            move_id: deepcopy(self._replay._running[move_id])
            for move_id in self._replay.running_move_ids
        }
        self._revision += 1
        self._current_actions = {}
        return self.get_state() if snapshot else None

    def recompute(
        self,
        task: Problem,
        current_time: float,
        selector: "MachineSelector | Callable[[MachineSnapshot, Sequence[RobotAction]], str]",
        *,
        initial_state: Optional[MachineState] = None,
    ) -> MachineRunResult:
        """从当前通知现场取消未开始旧 Move，并立即生成下一代计划。

        Running Move 只投影自身完成效果；Machine 不执行其旧计划后继，也不
        要求切点达到关门或空手状态。新任务 ``task`` 必须已经包含仍在机的
        旧物料和本轮新增物料。实时层合入新物料后，可通过 ``initial_state``
        提供同一切点的扩展状态；这不会替换已提交 Move 历史或 MoveID 序列。
        """
        from src.validation.replay import MoveStateReplay

        cutoff = float(current_time)
        committed: list[dict] = []
        next_state = self.state.clone()
        if self._replay is not None:
            planned_by_id = {
                int(move["MoveID"]): move
                for move in self._replay.materialized_plan
                if isinstance(move.get("MoveID"), int)
            }
            for move_id in sorted(self._replay.running_move_ids):
                move = planned_by_id[move_id]
                self._replay.update_move_state(
                    {
                        "MoveID": move_id,
                        "MoveState": MoveStateReplay.DONE,
                        "EndTime": float(move.get("EndTime") or cutoff),
                    },
                    snapshot=False,
                )
            committed = self._replay.executed_moves
            next_state = self._replay.state.clone()
        else:
            committed = [
                deepcopy(move)
                for move in self._moves
                if float(move.get("StartTime") or 0.0) < cutoff - TIME_TOLERANCE
            ]
        if initial_state is not None:
            next_state = initial_state.clone()

        last_move_id = max(
            (
                int(move.get("MoveID") or 0)
                for move in [*self._moves, *committed]
            ),
            default=self._next_move_id - 1,
        )
        self.task = task
        self.state = next_state
        self.current_time = cutoff
        self._initial_state = next_state.clone()
        self._durations = Durations(task)
        self._wafer_by_material = {wafer.mat_id: wafer for wafer in task.wafers}
        self._moves = deepcopy(committed)
        self._active_moves = {}
        self._next_move_id = last_move_id + 1
        self._replay = None
        previous_process_visits = dict(self._process_visits)
        previous_pre_cleaned = set(self._pre_cleaned)
        previous_post_cleaned = set(self._post_cleaned)
        self._process_visits = {}
        self._pre_cleaned = previous_pre_cleaned
        self._post_cleaned = previous_post_cleaned
        self._revision += 1
        self._current_actions = {}
        self._refresh_job_constraints()
        valid_pjobs = {wafer.pjob_name for wafer in task.wafers}
        self._process_visits = {
            key: value
            for key, value in previous_process_visits.items()
            if key[0] in valid_pjobs
        }
        self._apply_runtime_availability()
        self._schedule_pending_services()
        return self.run(selector)

    def fork(self) -> "Machine":
        """复制完整规划状态，供 RL rollout 或前瞻搜索使用。"""
        cloned = Machine.__new__(Machine)
        cloned.task = deepcopy(self.task)
        cloned.state = self.state.clone()
        cloned.current_time = self.current_time
        cloned._initial_state = self._initial_state.clone()
        cloned._durations = Durations(cloned.task)
        cloned._wafer_by_material = {
            wafer.mat_id: wafer for wafer in cloned.task.wafers
        }
        cloned._moves = deepcopy(self._moves)
        cloned._committed_actions = list(self._committed_actions)
        cloned._active_moves = deepcopy(self._active_moves)
        cloned._revision = self._revision
        cloned._next_move_id = self._next_move_id
        cloned._committed_action_count = self._committed_action_count
        # 候选属于旧对象的只读预览；分支首次决策时按克隆状态重新枚举。
        cloned._current_actions = {}
        cloned._replay = None
        cloned._process_visits = deepcopy(self._process_visits)
        cloned._release_predecessors = deepcopy(self._release_predecessors)
        cloned._remaining_process_visits = deepcopy(self._remaining_process_visits)
        cloned._process_job_predecessors = deepcopy(
            self._process_job_predecessors
        )
        cloned._pre_cleaned = set(self._pre_cleaned)
        cloned._post_cleaned = set(self._post_cleaned)
        cloned._allow_loadlock_exchange = self._allow_loadlock_exchange
        return cloned

    def replace_problem(self, task: Problem, *, current_time: float) -> None:
        """在保留当前物理投影和资源日历的前提下切换任务集合。"""
        self.task = task
        self.current_time = float(current_time)
        self._durations = Durations(task)
        self._wafer_by_material = {wafer.mat_id: wafer for wafer in task.wafers}
        self._refresh_job_constraints()
        for wafer in task.wafers:
            for stage in wafer.stages:
                self.state.ensure_station(
                    stage.chamber,
                    int(stage.slot) + FIRST_SLOT_ID,
                )
        self._revision += 1
        self._current_actions = {}

    def preserve_running_moves(
        self,
        moves: Sequence[Mapping[str, Any]],
        *,
        cutoff: float,
    ) -> None:
        """在重算切点保留已经开始且尚未结束的原子 Move。

        未开始旧 Move 不进入 Machine；Running Move 的资源释放时间和预期物理
        效果投影到完成态，但 ``current_time`` 保持原始切点。
        """
        from src.validation.replay import MoveStateReplay

        running = [
            deepcopy(dict(move))
            for move in moves
            if float(move.get("StartTime") or 0.0) < float(cutoff) - TIME_TOLERANCE
            and float(move.get("EndTime") or 0.0) > float(cutoff) + TIME_TOLERANCE
        ]
        if not running:
            return
        replay = MoveStateReplay(self.task, running, self.state)
        for move in sorted(running, key=lambda item: float(item.get("StartTime") or 0.0)):
            replay.update_move_state(
                {
                    "MoveID": int(move["MoveID"]),
                    "MoveState": MoveStateReplay.RUNNING,
                    "StartTime": float(move.get("StartTime") or cutoff),
                },
                snapshot=False,
            )
        for move in sorted(running, key=lambda item: float(item.get("EndTime") or 0.0)):
            replay.update_move_state(
                {
                    "MoveID": int(move["MoveID"]),
                    "MoveState": MoveStateReplay.DONE,
                    "EndTime": float(move.get("EndTime") or cutoff),
                },
                snapshot=False,
            )
        self.state = replay.state.clone()
        self._active_moves = {int(move["MoveID"]): move for move in running}
        self._moves.extend(running)
        self._next_move_id = max(
            self._next_move_id,
            max((int(move["MoveID"]) for move in running), default=0) + 1,
        )
        self.current_time = float(cutoff)
        self._revision += 1

    def _material_locations(
        self,
    ) -> Dict[Any, Tuple[str, str, int, MaterialState, Optional[SlotPhase]]]:
        """建立物料到站点或机器人手槽的位置索引。"""
        result: Dict[
            Any,
            Tuple[str, str, int, MaterialState, Optional[SlotPhase]],
        ] = {}
        for station_name, station in self.state.stations.items():
            for slot_id, slot in station.slots.items():
                if slot.material is not None:
                    result[slot.material.material_id] = (
                        "station",
                        station_name,
                        slot_id,
                        slot.material,
                        slot.phase,
                    )
        for robot in self.state.robots.values():
            for slot_id, material in robot.hands.items():
                if material is not None:
                    result[material.material_id] = (
                        "robot",
                        robot.name,
                        slot_id,
                        material,
                        None,
                    )
        return result

    def _apply_runtime_availability(self) -> None:
        """把实时重算的相对释放下界写入 Machine 绝对资源日历。"""
        availability = self.task.runtime_availability
        if availability is None:
            return
        for station_name, ready_after in availability.station_ready.items():
            station = self.state.stations.get(station_name)
            if station is None:
                continue
            ready_at = self.current_time + max(float(ready_after), 0.0)
            station.door_busy_until = max(station.door_busy_until, ready_at)
            station.transfer_busy_until = max(station.transfer_busy_until, ready_at)
            station.environment_busy_until = max(
                station.environment_busy_until,
                ready_at,
            )
        for (station_name, slot_id), ready_after in availability.slot_ready.items():
            station = self.state.stations.get(station_name)
            if station is None:
                continue
            slot = station.slots.get(int(slot_id))
            if slot is not None:
                slot.busy_until = max(
                    slot.busy_until,
                    self.current_time + max(float(ready_after), 0.0),
                )
        for robot_name, ready_after in availability.robot_ready.items():
            robot = self.state.resolve_robot(robot_name)
            if robot is not None:
                robot.busy_until = max(
                    robot.busy_until,
                    self.current_time + max(float(ready_after), 0.0),
                )
        for robot_name, position in availability.robot_positions.items():
            robot = self.state.resolve_robot(robot_name)
            if robot is not None and position:
                robot.position = str(position)
        for material_id, ready_after in availability.material_ready.items():
            ready_at = self.current_time + max(float(ready_after), 0.0)
            for station in self.state.stations.values():
                for slot in station.slots.values():
                    if (
                        slot.material is not None
                        and slot.material.material_id == material_id
                    ):
                        slot.busy_until = max(slot.busy_until, ready_at)
        for station_name, environment in availability.loadlock_environment.items():
            station = self.state.stations.get(station_name)
            if isinstance(station, LoadLockState) and environment in {
                ATMOSPHERE,
                VACUUM,
            }:
                station.environment = environment

    @staticmethod
    def _empty_robot_slot(
        hands: Mapping[int, Optional[MaterialState]],
    ) -> Optional[int]:
        """返回编号最小的空机器人手槽。"""
        return next(
            (slot_id for slot_id, material in sorted(hands.items()) if material is None),
            None,
        )

    @staticmethod
    def _stage_index(
        wafer: Wafer,
        material: MaterialState,
        location: str,
    ) -> int:
        """由 StepID 或物理位置确定物料当前 Route 工序。"""
        if isinstance(material.step_id, int) and 0 <= material.step_id < len(wafer.stages):
            return int(material.step_id)
        matches = [
            index
            for index, stage in enumerate(wafer.stages)
            if stage.chamber == location or location in (stage.cands or ())
        ]
        if not matches:
            raise ValueError(
                f"MatID={wafer.mat_id} 的当前位置 {location} 不在 Route 中"
            )
        return max(matches)

    def _preview_transfer(
        self,
        *,
        wafer: Wafer,
        stage_index: int,
        robot_name: str,
        robot_slot: int,
        material: MaterialState,
        source_station: Optional[str],
        source_slot: Optional[int],
        destination_station: str,
        destination_slot: int,
        already_held: bool,
        swap_material: Optional[MaterialState],
        receive_robot_slot: Optional[int],
        exchange_material: Optional[MaterialState],
        exchange_slot: Optional[int],
        defer_loadlock_service: bool,
    ) -> Optional[RobotAction]:
        """在隔离资源日历上计算一个搬运意图的完整 Move 预览。"""
        robot = self.state.resolve_robot(robot_name)
        destination = self.state.stations[destination_station]
        following = wafer.stages[stage_index + 1]
        if robot is None:
            return None
        moves: list[dict] = []
        destination_environment_changed = self._environment_change_required(
            destination,
            robot_name,
        )
        destination_environment_prepared = False
        source_move_start = 0
        if (
            not already_held
            and destination_environment_changed
            and source_station != destination_station
            and destination.is_load_lock
            and all(slot.material is None for slot in destination.slots.values())
        ):
            # 空 LoadLock 的压力切换无需等待源站晶圆被取出。把它放在同一
            # 原子意图的前段并与源站准备并行，可避免先 Pick 再等抽/充气而
            # 造成无意义的 Robot 持片；资源日历仍以目标腔的门、传输和环境
            # 释放时刻为下界。
            destination_setup_start = max(
                self.current_time,
                float(destination.door_busy_until),
                float(destination.transfer_busy_until),
                float(destination.environment_busy_until),
                float(destination.slots[destination_slot].busy_until),
                (
                    float(destination.slots[exchange_slot].busy_until)
                    if exchange_slot is not None
                    else 0.0
                ),
            )
            setup_end = self._append_environment_setup(
                moves,
                destination,
                robot_name,
                destination_slot,
                destination_setup_start,
                material_id=None,
            )
            destination_environment_prepared = (
                setup_end > destination_setup_start + TIME_TOLERANCE
            )
            source_move_start = len(moves)
        cursor = max(self.current_time, float(robot.busy_until))
        first_start: Optional[float] = None
        robot_position = robot.position

        def emit(move_type: int, start: float, end: float, **fields: Any) -> None:
            """向预览追加协议 Move，并记录事务首个起点。"""
            nonlocal first_start
            if first_start is None:
                first_start = start
            move = {
                "MoveType": move_type,
                "MoveID": self._next_move_id + len(moves),
                "StartTime": float(start),
                "EndTime": float(end),
                **fields,
            }
            moves.append(move)

        if not already_held:
            if not source_station or source_slot is None:
                return None
            source = self.state.stations.get(source_station)
            if source is None:
                return None
            source_state = source.slots[source_slot]
            cursor = max(
                cursor,
                float(source_state.busy_until),
                float(source.door_busy_until),
                float(source.transfer_busy_until),
                float(source.environment_busy_until),
            )
            if robot_position and robot_position != source_station:
                duration = self._durations.move(robot_name)
                emit(
                    PRE_TRANS_MOVE,
                    cursor,
                    cursor + duration,
                    ModuleName=robot_name,
                    Robot=robot_name,
                    RobotSlotList=[robot_slot],
                    SlotList=[source_slot],
                    SrcStationList=[robot_position],
                    DestStationList=[source_station],
                    MatIDList=[],
                )
                cursor += duration
            source_environment_changed = self._environment_change_required(
                source,
                robot_name,
            )
            cursor = self._append_environment_setup(
                moves,
                source,
                robot_name,
                source_slot,
                cursor,
                material_id=None,
            )
            if (
                not is_doorless_station(source_station)
                and (
                    source.door is DoorState.CLOSED
                    or source_environment_changed
                )
            ):
                duration = self._durations.pick_pre(robot_name, source_station)
                emit(
                    PREPARE_MOVE,
                    cursor,
                    cursor + duration,
                    ModuleName=source_station,
                    Station=source_station,
                    SlotList=[source_slot],
                    MatIDList=[material.material_id],
                    PJobName=[material.pjob_name],
                    RelatedActionType=RELATED_ACTION_PICK,
                    RelatedRobotType=self._related_robot_type(robot_name),
                )
                cursor += duration
            duration = self._durations.pick_t(robot_name, source_station)
            emit(
                PICK_MOVE,
                cursor,
                cursor + duration,
                ModuleName=robot_name,
                Robot=robot_name,
                RobotSlotList=[robot_slot],
                SlotList=[source_slot],
                SrcStationList=[source_station],
                SrcSlotList=[source_slot],
                MatIDList=[material.material_id],
                PJobName=[material.pjob_name],
            )
            cursor += duration
            if not is_doorless_station(source_station):
                duration = self._durations.pick_post(robot_name, source_station)
                source_close_end = cursor + duration
                emit(
                    COMPLETE_MOVE,
                    cursor,
                    source_close_end,
                    ModuleName=source_station,
                    Station=source_station,
                    SlotList=[source_slot],
                    MatIDList=[material.material_id],
                    PJobName=[material.pjob_name],
                )
            else:
                source_close_end = cursor
            if isinstance(source, LoadLockState):
                self._append_deferred_loadlock_service(
                    moves,
                    source,
                    source_slot,
                    source_close_end,
                )
            robot_position = source_station

        destination_ready_time = max(
            float(destination.door_busy_until),
            float(destination.transfer_busy_until),
            float(destination.environment_busy_until),
            float(destination.slots[destination_slot].busy_until),
            (
                float(destination.slots[exchange_slot].busy_until)
                if exchange_slot is not None
                else 0.0
            ),
            max(
                (
                    float(move.get("EndTime") or 0.0)
                    for move in moves[:source_move_start]
                ),
                default=0.0,
            ),
        )
        if not already_held and moves and destination_ready_time > cursor:
            # 策略已经选定完整搬运事务，但目标站仍在加工或清洁时，不应立即
            # Pick 后持片等待。把源站侧动作整体右移到目标释放前；后半事务的
            # 时刻和 finish_time 不变，因此不会损伤 makespan。earliest_start
            # 仍保留未右移前的逻辑使能时刻，供策略和既有模型继续判断候选。
            just_in_time_delay = destination_ready_time - cursor
            source_stage = wafer.stages[stage_index]
            if (
                source_stage.stage_type == "process"
                and float(source_stage.residency) > 0.0
                and source_slot is not None
            ):
                pick_move = next(
                    (
                        move
                        for move in moves
                        if move.get("MoveType") == PICK_MOVE
                        and str((move.get("SrcStationList") or [""])[0])
                        == str(source_station)
                    ),
                    None,
                )
                if pick_move is not None:
                    residency_deadline = (
                        float(source_state.busy_until)
                        + float(source_stage.residency)
                    )
                    just_in_time_delay = min(
                        just_in_time_delay,
                        max(
                            0.0,
                            residency_deadline
                            - float(pick_move.get("StartTime") or 0.0),
                        ),
                    )
            _delay_moves(moves[source_move_start:], just_in_time_delay)
            cursor += just_in_time_delay
        cursor = max(cursor, destination_ready_time)
        destination_approach_start = cursor
        if robot_position and robot_position != destination_station:
            duration = self._durations.move(robot_name)
            emit(
                PRE_TRANS_MOVE,
                cursor,
                cursor + duration,
                ModuleName=robot_name,
                Robot=robot_name,
                RobotSlotList=[robot_slot],
                SlotList=[destination_slot],
                SrcStationList=[robot_position],
                DestStationList=[destination_station],
                MatIDList=[material.material_id],
                PJobName=[material.pjob_name],
            )
            cursor += duration
        if not destination_environment_prepared:
            cursor = self._append_environment_setup(
                moves,
                destination,
                robot_name,
                destination_slot,
                cursor,
                material_id=None,
            )
        if (
            not is_doorless_station(destination_station)
            and (
                destination.door is DoorState.CLOSED
                or destination_environment_changed
            )
        ):
            duration = self._durations.place_pre(robot_name, destination_station)
            prepare_start = (
                max(destination_approach_start, cursor - duration)
                if (
                    robot_position
                    and robot_position != destination_station
                    and not destination_environment_changed
                )
                else cursor
            )
            emit(
                PREPARE_MOVE,
                prepare_start,
                prepare_start + duration,
                ModuleName=destination_station,
                Station=destination_station,
                SlotList=[destination_slot],
                MatIDList=[material.material_id],
                PJobName=[material.pjob_name],
                RelatedActionType=(
                    RELATED_ACTION_SWAP
                    if (
                        swap_material is not None
                        or (
                            exchange_material is not None
                            and receive_robot_slot is not None
                        )
                    )
                    else RELATED_ACTION_PLACE
                ),
                RelatedRobotType=self._related_robot_type(robot_name),
            )
            cursor = max(cursor, prepare_start + duration)
        if swap_material is None and (
            exchange_material is None or receive_robot_slot is None
        ):
            duration = self._durations.place_t(robot_name, destination_station)
            emit(
                PLACE_MOVE,
                cursor,
                cursor + duration,
                ModuleName=robot_name,
                Robot=robot_name,
                RobotSlotList=[robot_slot],
                SlotList=[destination_slot],
                DestStationList=[destination_station],
                DestSlotList=[destination_slot],
                MatIDList=[material.material_id],
                PJobName=[material.pjob_name],
                StepIDList=[stage_index + 1],
            )
            cursor += duration
            if exchange_material is not None:
                if exchange_slot is None:
                    return None
                duration = self._durations.pick_t(robot_name, destination_station)
                emit(
                    PICK_MOVE,
                    cursor,
                    cursor + duration,
                    ModuleName=robot_name,
                    Robot=robot_name,
                    RobotSlotList=[robot_slot],
                    SlotList=[exchange_slot],
                    SrcStationList=[destination_station],
                    SrcSlotList=[exchange_slot],
                    MatIDList=[exchange_material.material_id],
                    PJobName=[exchange_material.pjob_name],
                )
                cursor += duration
        else:
            if receive_robot_slot is None:
                return None
            station_send_slot = (
                exchange_slot
                if exchange_material is not None
                else destination_slot
            )
            station_send_material = (
                exchange_material
                if exchange_material is not None
                else swap_material
            )
            if station_send_slot is None or station_send_material is None:
                return None
            duration = (
                self._durations.place_t(robot_name, destination_station)
                + self._durations.pick_t(robot_name, destination_station)
            )
            emit(
                SWAP_MOVE,
                cursor,
                cursor + duration,
                ModuleName=robot_name,
                Robot=robot_name,
                SlotList=[destination_slot, station_send_slot],
                MatIDList=[
                    station_send_material.material_id,
                    material.material_id,
                ],
                PJobName=[
                    station_send_material.pjob_name,
                    material.pjob_name,
                ],
                StepIDList=[
                    station_send_material.step_id,
                    stage_index + 1,
                ],
                RecvMatStepIDList=[station_send_material.step_id],
                SendMatStepIDList=[stage_index + 1],
                StationList=[destination_station, destination_station],
                StnRecvSlotList=[destination_slot],
                StnSendSlotList=[station_send_slot],
                RecvMatList=[station_send_material.material_id],
                SendMatList=[material.material_id],
                RecvSlotList=[receive_robot_slot],
                SendSlotList=[robot_slot],
                SwapMode=0,
            )
            cursor += duration
        if not is_doorless_station(destination_station):
            duration = self._durations.place_post(robot_name, destination_station)
            emit(
                COMPLETE_MOVE,
                cursor,
                cursor + duration,
                ModuleName=destination_station,
                Station=destination_station,
                SlotList=[destination_slot],
                MatIDList=(
                    [material.material_id, exchange_material.material_id]
                    if exchange_material is not None
                    else [material.material_id]
                ),
                PJobName=(
                    [material.pjob_name, exchange_material.pjob_name]
                    if exchange_material is not None
                    else [material.pjob_name]
                ),
            )
            cursor += duration
        transfer_finish = cursor
        if not defer_loadlock_service:
            self._append_automatic_service(
                moves,
                following,
                destination,
                destination_slot,
                material,
                cursor,
                stage_index + 1,
            )
        projected_ready_time = max(
            (float(move.get("EndTime") or transfer_finish) for move in moves),
            default=float(transfer_finish),
        )
        action_id = (
            f"r{self._revision}:w{wafer.wid}:s{stage_index}:"
            f"{robot_name}:{source_station or 'held'}:{destination_station}:"
            f"{destination_slot}"
            + (
                f":exchange:{exchange_material.material_id}"
                if exchange_material is not None
                else ""
            )
        )
        source_stage = wafer.stages[stage_index]
        residency_deadline = None
        if (
            source_stage.stage_type == "process"
            and float(source_stage.residency) > 0.0
            and source_station is not None
            and source_slot is not None
        ):
            residency_deadline = (
                float(self.state.stations[source_station].slots[source_slot].busy_until)
                + float(source_stage.residency)
            )
        return RobotAction(
            revision=self._revision,
            action_id=action_id,
            kind=(
                "ll_exchange"
                if exchange_material is not None
                else "ll_park"
                if defer_loadlock_service
                else "swap"
                if swap_material is not None
                else "held_place"
                if already_held
                else "transfer"
            ),
            robot=robot_name,
            material_ids=(
                (material.material_id, exchange_material.material_id)
                if exchange_material is not None
                else (material.material_id, swap_material.material_id)
                if swap_material is not None
                else (material.material_id,)
            ),
            source_station=source_station,
            source_slot=source_slot,
            destination_station=destination_station,
            destination_slot=destination_slot,
            robot_slots=(
                (robot_slot, int(receive_robot_slot))
                if receive_robot_slot is not None
                else (robot_slot,)
            ),
            earliest_start=(
                float(first_start) if first_start is not None else self.current_time
            ),
            finish_time=projected_ready_time,
            move_preview=tuple(_freeze(move) for move in moves),
            wafer_id=int(wafer.wid),
            stage_index=stage_index,
            flow_kind=self._action_flow_kind(
                following,
                exchange=exchange_material is not None,
            ),
            residency_deadline=residency_deadline,
            projected_ready_time=projected_ready_time,
        )

    def _loadlock_exchange_partner(
        self,
        *,
        wafer: Wafer,
        stage_index: int,
        robot_name: str,
        destination: Any,
        destination_slot: int,
    ) -> Optional[tuple[int, MaterialState]]:
        """寻找可在同一次 LoadLock 开门内反向取出的晶圆。

        交换的主晶圆先放入空逻辑槽，反向晶圆再由同一只已经空出的手取走，
        因此单臂 Robot 也能执行。两片晶圆必须位于相反的 LoadLock 方向，
        且反向晶圆的下一跳确实由当前 Robot 搬运。
        """
        following = wafer.stages[stage_index + 1]
        if (
            not isinstance(destination, LoadLockState)
            or following.stage_type != "loadlock"
            or following.ll_type not in {"entry", "exit"}
        ):
            return None
        opposite_direction = "exit" if following.ll_type == "entry" else "entry"
        for slot_id, slot in sorted(destination.slots.items()):
            partner = slot.material
            if (
                slot_id == destination_slot
                or partner is None
                or slot.phase is not SlotPhase.COMPLETED
            ):
                continue
            partner_wafer = self._wafer_by_material.get(partner.material_id)
            if partner_wafer is None:
                continue
            partner_stage_index = self._stage_index(
                partner_wafer,
                partner,
                destination.name,
            )
            if partner_stage_index >= len(partner_wafer.transports):
                continue
            partner_stage = partner_wafer.stages[partner_stage_index]
            if (
                partner_stage.stage_type == "loadlock"
                and partner_stage.ll_type == opposite_direction
                and str(partner_wafer.transports[partner_stage_index]) == robot_name
            ):
                return slot_id, partner
        return None

    @staticmethod
    def _action_flow_kind(stage: Stage, *, exchange: bool) -> str:
        """把 LoadLock 搬运标成策略可直接识别的流向。"""
        if stage.stage_type != "loadlock":
            return "internal"
        if stage.ll_type == "entry":
            return "atmosphere_exchange" if exchange else "feed"
        if stage.ll_type == "exit":
            return "vacuum_exchange" if exchange else "drain"
        return "internal"

    def _append_environment_setup(
        self,
        moves: list[dict],
        station: Any,
        robot_name: str,
        slot_id: int,
        cursor: float,
        *,
        material_id: Optional[Any],
    ) -> float:
        """按机器人所在侧为 LoadLock 自动补空抽或空充。"""
        if not isinstance(station, LoadLockState):
            return cursor
        required = (
            ATMOSPHERE
            if self._related_robot_type(robot_name) == RELATED_ROBOT_ATMOSPHERE
            else VACUUM
        )
        if station.environment == required:
            return cursor
        if station.door is DoorState.OPEN:
            close_duration = self._durations.pick_post(robot_name, station.name)
            moves.append({
                "MoveType": COMPLETE_MOVE,
                "MoveID": self._next_move_id + len(moves),
                "StartTime": float(cursor),
                "EndTime": float(cursor + close_duration),
                "ModuleName": station.name,
                "Station": station.name,
                "SlotList": [slot_id],
                "MatIDList": [],
            })
            cursor += close_duration
        chamber = self.task.chambers.get(station.name)
        duration = (
            float(chamber.vent_time or 0.0)
            if required == ATMOSPHERE and chamber is not None
            else float(chamber.pump_time or 0.0)
            if chamber is not None
            else 0.0
        )
        moves.append(
            {
                "MoveType": PRE_PREPARE_MOVE,
                "MoveID": self._next_move_id + len(moves),
                "StartTime": float(cursor),
                "EndTime": float(cursor + duration),
                "ModuleName": station.name,
                "Station": station.name,
                "SlotList": [slot_id],
                "MatIDList": [] if material_id is None else [material_id],
                "LastState": station.environment,
                "CurState": required,
            }
        )
        return cursor + duration

    def _environment_change_required(
        self,
        station: Any,
        robot_name: str,
    ) -> bool:
        """判断当前 Robot 访问 LoadLock 前是否必须切换压力态。"""
        if not isinstance(station, LoadLockState):
            return False
        required = (
            ATMOSPHERE
            if self._related_robot_type(robot_name) == RELATED_ROBOT_ATMOSPHERE
            else VACUUM
        )
        return station.environment != required

    def _append_automatic_service(
        self,
        moves: list[dict],
        stage: Stage,
        station: Any,
        slot_id: int,
        material: MaterialState,
        start: float,
        step_id: int,
    ) -> None:
        """放片后自动追加加工或带片压力转换。"""
        duration = max(float(stage.proc), 0.0)
        if duration <= TIME_TOLERANCE:
            return
        common = {
            "MoveID": self._next_move_id + len(moves),
            "StartTime": float(start),
            "EndTime": float(start + duration),
            "ModuleName": station.name,
            "Station": station.name,
            "SlotList": [slot_id],
            "MatIDList": [material.material_id],
            "PJobName": [material.pjob_name],
            "StepID": step_id,
        }
        if isinstance(station, LoadLockState):
            target = VACUUM if stage.ll_type == "entry" else ATMOSPHERE
            moves.append(
                {
                    "MoveType": PRE_PREPARE_MOVE,
                    **common,
                    "LastState": (
                        ATMOSPHERE if target == VACUUM else VACUUM
                    ),
                    "CurState": target,
                }
            )
        else:
            moves.append({"MoveType": PROCESS_MOVE, **common})

    def _append_deferred_loadlock_service(
        self,
        moves: list[dict],
        station: LoadLockState,
        departing_slot_id: int,
        start: float,
    ) -> None:
        """两片 LoadLock 取走一片后，为剩余停放片追加延迟压力转换。

        压力动作与 Robot 离开后的搬运并行，不推进搬运事务的 ``cursor``；
        但仍进入动作预览和资源日历，保证另一侧 Robot 只能在转换完成后访问。
        """
        pending = [
            (slot_id, slot)
            for slot_id, slot in station.slots.items()
            if (
                slot_id != departing_slot_id
                and slot.material is not None
                and slot.phase is SlotPhase.UNPROCESSED
            )
        ]
        occupied_count = sum(
            slot.material is not None for slot in station.slots.values()
        )
        if occupied_count != 2 or len(pending) != 1:
            return
        slot_id, slot = pending[0]
        material = slot.material
        if material is None:
            return
        wafer = self._wafer_by_material.get(material.material_id)
        if wafer is None:
            return
        stage_index = self._stage_index(wafer, material, station.name)
        if stage_index >= len(wafer.stages):
            return
        stage = wafer.stages[stage_index]
        if stage.stage_type != "loadlock":
            return
        self._append_automatic_service(
            moves,
            stage,
            station,
            slot_id,
            material,
            start,
            stage_index,
        )

    def _apply_projected_action(
        self,
        action: RobotAction,
        committed_moves: Sequence[Mapping[str, Any]],
    ) -> None:
        """把已提交搬运及其自动服务投影到完成态和资源日历。"""
        material_id = action.material_ids[0]
        locations = self._material_locations()
        location = locations[material_id]
        material = location[3]
        if location[0] == "station":
            source = self.state.stations[location[1]]
            source_slot = source.slots[location[2]]
            source_slot.material = None
            source_slot.phase = SlotPhase.EMPTY
        else:
            source_robot = self.state.robots[location[1]]
            source_robot.hands[location[2]] = None

        destination = self.state.stations[action.destination_station]
        target_slot = destination.slots[action.destination_slot]
        outgoing_material = target_slot.material if action.kind == "swap" else None
        exchange_wafer = (
            self._wafer_by_material.get(action.material_ids[1])
            if action.kind == "ll_exchange" and len(action.material_ids) > 1
            else None
        )
        exchanged_state: Optional[MaterialState] = None
        if exchange_wafer is not None:
            for slot_id, slot in destination.slots.items():
                if (
                    slot_id != action.destination_slot
                    and slot.material is not None
                    and slot.material.material_id == action.material_ids[1]
                ):
                    exchanged_state = slot.material
                    slot.material = None
                    slot.phase = SlotPhase.EMPTY
                    slot.busy_until = max(slot.busy_until, action.finish_time)
                    slot.busy_action = ""
                    break
        target_slot.material = MaterialState(
            material.material_id,
            material.pjob_name,
            action.stage_index + 1,
        )
        target_slot.phase = (
            SlotPhase.UNPROCESSED
            if action.kind == "ll_park"
            else SlotPhase.COMPLETED
        )
        target_slot.busy_until = max(
            target_slot.busy_until,
            max(
                (
                    float(move.get("EndTime") or action.finish_time)
                    for move in committed_moves
                    if str(move.get("Station") or "") == action.destination_station
                ),
                default=action.finish_time,
            ),
        )
        target_slot.busy_action = ""

        robot = self.state.resolve_robot(action.robot)
        if robot is not None:
            if action.kind == "swap" and outgoing_material is not None:
                send_slot, receive_slot = action.robot_slots
                robot.hands[send_slot] = None
                robot.hands[receive_slot] = outgoing_material
            elif action.kind == "ll_exchange" and exchanged_state is not None:
                send_slot = action.robot_slots[0]
                receive_slot = (
                    action.robot_slots[1]
                    if len(action.robot_slots) > 1
                    else send_slot
                )
                robot.hands[send_slot] = None
                robot.hands[receive_slot] = exchanged_state
            robot.position = action.destination_station
            robot.busy_until = max(
                robot.busy_until,
                max(
                    (
                        float(move.get("EndTime") or action.finish_time)
                        for move in committed_moves
                        if str(move.get("Robot") or "") == action.robot
                    ),
                    default=action.finish_time,
                ),
            )
        for station_name in {
            str(move.get("Station") or "")
            for move in committed_moves
            if move.get("Station")
        }:
            station = self.state.stations.get(station_name)
            if station is None:
                continue
            related = [
                move
                for move in committed_moves
                if str(move.get("Station") or "") == station_name
            ]
            station.door = DoorState.CLOSED
            station.door_busy_until = max(
                station.door_busy_until,
                max(
                    (
                        float(move.get("EndTime") or 0.0)
                        for move in related
                        if move.get("MoveType") in {PREPARE_MOVE, COMPLETE_MOVE}
                    ),
                    default=0.0,
                ),
            )
            station.transfer_busy_until = max(
                station.transfer_busy_until,
                max(
                    (
                        float(move.get("EndTime") or 0.0)
                        for move in committed_moves
                        if (
                            move.get("MoveType") in {
                                PICK_MOVE,
                                PLACE_MOVE,
                                SWAP_MOVE,
                            }
                            and station_name
                            in {
                                *(str(value) for value in move.get("SrcStationList") or []),
                                *(str(value) for value in move.get("DestStationList") or []),
                            }
                        )
                    ),
                    default=0.0,
                ),
            )
            environment_moves = [
                move
                for move in related
                if move.get("MoveType") == PRE_PREPARE_MOVE
            ]
            if isinstance(station, LoadLockState) and environment_moves:
                last = max(
                    environment_moves,
                    key=lambda move: float(move.get("EndTime") or 0.0),
                )
                station.environment = str(last.get("CurState") or station.environment)
                station.environment_busy_until = max(
                    station.environment_busy_until,
                    float(last.get("EndTime") or 0.0),
                )
                for environment_move in environment_moves:
                    material_ids = list(environment_move.get("MatIDList") or [])
                    if not material_ids:
                        continue
                    material_id = material_ids[0]
                    for slot in station.slots.values():
                        if (
                            slot.material is not None
                            and slot.material.material_id == material_id
                        ):
                            slot.phase = SlotPhase.COMPLETED
                            slot.busy_until = max(
                                slot.busy_until,
                                float(environment_move.get("EndTime") or 0.0),
                            )
                            slot.busy_action = ""
                            break

    def _refresh_job_constraints(self) -> None:
        """重建当前问题的发片偏序和各 PJob/PM 剩余加工次数。"""
        self._release_predecessors = release_predecessors(self.task.wafers)
        remaining: Dict[tuple[str, str], int] = {}
        pjob_first_wid: Dict[str, int] = {}
        pjob_priority: Dict[str, int] = {}
        pjob_cjob: Dict[str, str] = {}
        cjob_first_wid: Dict[str, int] = {}
        pjobs_by_chamber: Dict[str, set[str]] = {}
        for wafer in self.task.wafers:
            pjob_first_wid[wafer.pjob_name] = min(
                pjob_first_wid.get(wafer.pjob_name, int(wafer.wid)),
                int(wafer.wid),
            )
            pjob_priority[wafer.pjob_name] = int(wafer.pjob_priority)
            pjob_cjob[wafer.pjob_name] = wafer.cjob_id
            cjob_first_wid[wafer.cjob_id] = min(
                cjob_first_wid.get(wafer.cjob_id, int(wafer.wid)),
                int(wafer.wid),
            )
            for stage in wafer.stages:
                if stage.stage_type != "process":
                    continue
                key = (wafer.pjob_name, str(stage.chamber))
                remaining[key] = remaining.get(key, 0) + 1
                pjobs_by_chamber.setdefault(str(stage.chamber), set()).add(
                    wafer.pjob_name
                )
        self._remaining_process_visits = remaining
        self._process_job_predecessors = {}
        for chamber, pjob_names in pjobs_by_chamber.items():
            ordered = sorted(
                pjob_names,
                key=lambda name: (
                    cjob_first_wid.get(pjob_cjob.get(name, ""), 0),
                    pjob_priority.get(name, 1),
                    pjob_first_wid.get(name, 0),
                    name,
                ),
            )
            for previous, current in zip(ordered, ordered[1:]):
                if (
                    _matching_specs(self.task.post_clean, previous, chamber)
                    or _matching_specs(self.task.pre_clean, current, chamber)
                ):
                    self._process_job_predecessors[
                        (current, chamber)
                    ] = previous

    def _release_is_blocked(
        self,
        wafer_id: int,
        locations: Mapping[Any, tuple],
    ) -> bool:
        """判断晶圆是否仍在等待 PJob 内 FIFO 或 PJob 优先级前驱发片。"""
        current = next(
            (
                wafer
                for wafer in self.task.wafers
                if int(wafer.wid) == int(wafer_id)
            ),
            None,
        )
        if current is not None:
            first_process = next(
                (
                    stage
                    for stage in current.stages
                    if stage.stage_type == "process"
                ),
                None,
            )
            if (
                first_process is not None
                and self._process_job_boundary_blocked(
                    current.pjob_name,
                    str(first_process.chamber),
                )
            ):
                return True
            for blocker_cjob in current.dispatch_after:
                for blocker in self.task.wafers:
                    if blocker.cjob_id != blocker_cjob:
                        continue
                    location = locations.get(blocker.mat_id)
                    if location is None:
                        continue
                    if self._stage_index(
                        blocker,
                        location[3],
                        location[1],
                    ) < len(blocker.stages) - 1:
                        return True
        for predecessor_id in self._release_predecessors.get(int(wafer_id), ()):
            predecessor = next(
                (
                    wafer
                    for wafer in self.task.wafers
                    if int(wafer.wid) == int(predecessor_id)
                ),
                None,
            )
            if predecessor is None or predecessor.already_released:
                continue
            location = locations.get(predecessor.mat_id)
            if location is None:
                continue
            if self._stage_index(predecessor, location[3], location[1]) < 1:
                return True
        return False

    def _pre_clean_required(self, pjob_name: str, station_name: str) -> bool:
        """判断所属 PJob 首片进入指定 PM 前是否仍欠 PreClean。"""
        key = (pjob_name, station_name)
        return (
            key not in self._pre_cleaned
            and bool(_matching_specs(self.task.pre_clean, pjob_name, station_name))
        )

    def _fixed_process_destination_required(
        self,
        wafer: Wafer,
        stage: Stage,
    ) -> bool:
        """判断清洁边界是否要求沿解析阶段固定的 PM 分配执行。"""
        chamber = str(stage.chamber)
        product_pjob = self.task.dummy_owner.get(
            wafer.pjob_name,
            wafer.pjob_name,
        )
        return bool(
            _matching_specs(self.task.pre_clean, product_pjob, chamber)
            or _matching_specs(self.task.post_clean, product_pjob, chamber)
            or _matching_specs(self.task.dummy_wac, product_pjob, chamber)
            or (
                int(stage.clean_trigger) > 0
                and float(stage.clean_time) > TIME_TOLERANCE
            )
        )

    def _process_job_boundary_blocked(
        self,
        pjob_name: str,
        station_name: str,
    ) -> bool:
        """判断前一 PJob 在该 PM 的末片是否尚未离腔。"""
        predecessor = self._process_job_predecessors.get(
            (pjob_name, station_name)
        )
        return (
            predecessor is not None
            and self._remaining_process_visits.get(
                (predecessor, station_name),
                0,
            )
            > 0
        )

    def _departure_requires_empty_clean(
        self,
        wafer: Wafer,
        stage_index: int,
        station_name: str,
    ) -> bool:
        """判断离腔后是否必须先空腔执行 Wac、DummyWac 或 PostClean。"""
        if stage_index >= len(wafer.stages):
            return False
        stage = wafer.stages[stage_index]
        if stage.stage_type != "process":
            return False
        material = self.state.stations[station_name].slots[
            int(stage.slot) + FIRST_SLOT_ID
        ].material
        periodic_due = (
            material is not None
            and self._periodic_clean_due_stage(material, station_name) is not None
        )
        product_pjob = self.task.dummy_owner.get(
            wafer.pjob_name,
            wafer.pjob_name,
        )
        dummy_wac_due = (
            wafer.pjob_name in self.task.dummy_owner
            and bool(_matching_specs(
                self.task.dummy_wac,
                product_pjob,
                station_name,
            ))
        )
        post_due = (
            self._remaining_process_visits.get(
                (wafer.pjob_name, station_name),
                0,
            )
            <= 1
            and bool(_matching_specs(
                self.task.post_clean,
                wafer.pjob_name,
                station_name,
            ))
        )
        return periodic_due or dummy_wac_due or post_due

    def _schedule_action_pre_clean(
        self,
        action: RobotAction,
    ) -> Optional[float]:
        """在选中的 PJob 首片进入 PM 前即时插入其 PreClean。"""
        wafer = next(
            (
                candidate
                for candidate in self.task.wafers
                if int(candidate.wid) == int(action.wafer_id)
            ),
            None,
        )
        destination = str(action.destination_station)
        next_stage_index = int(action.stage_index) + 1
        if (
            wafer is None
            or next_stage_index >= len(wafer.stages)
            or wafer.stages[next_stage_index].stage_type != "process"
            or not self._pre_clean_required(wafer.pjob_name, destination)
        ):
            return None
        clean_end: Optional[float] = None
        for clean in _matching_specs(
            self.task.pre_clean,
            wafer.pjob_name,
            destination,
        ):
            clean_end = self._schedule_empty_clean(
                destination,
                float(clean.time),
                recipe=str(clean.recipe or ""),
                not_before=float(action.earliest_start),
            )
        if clean_end is not None:
            self._pre_cleaned.add((wafer.pjob_name, destination))
        return clean_end

    def _schedule_empty_clean(
        self,
        station_name: str,
        duration: float,
        *,
        recipe: str = "",
        not_before: Optional[float] = None,
    ) -> Optional[float]:
        """在指定站点不早于触发时刻追加无片清洁并返回结束时刻。"""
        station = self.state.stations.get(station_name)
        if station is None or duration <= TIME_TOLERANCE:
            return None
        empty_slot = next(
            (
                (slot_id, slot)
                for slot_id, slot in sorted(station.slots.items())
                if slot.material is None
            ),
            None,
        )
        if empty_slot is None:
            return None
        slot_id, slot = empty_slot
        start = max(
            self.current_time,
            station.door_busy_until,
            station.transfer_busy_until,
            slot.busy_until,
            float(not_before) if not_before is not None else self.current_time,
        )
        end = start + float(duration)
        self._moves.append({
            "MoveType": PROCESS_MOVE,
            "MoveID": self._next_move_id,
            "StartTime": start,
            "EndTime": end,
            "ModuleName": station_name,
            "Station": station_name,
            "SlotList": [slot_id],
            "MatIDList": [],
            "RecipeName": recipe,
        })
        self._next_move_id += 1
        slot.phase = SlotPhase.CLEANED
        slot.busy_until = end
        slot.busy_action = ""
        return end

    def _schedule_pending_services(self) -> None:
        """为非稳定初态中已放入但尚未加工的物料补关门和自动服务。"""
        for station in self.state.stations.values():
            for slot_id, slot in station.slots.items():
                material = slot.material
                if material is None or slot.phase is not SlotPhase.UNPROCESSED:
                    continue
                wafer = self._wafer_by_material.get(material.material_id)
                if wafer is None:
                    continue
                stage_index = self._stage_index(wafer, material, station.name)
                stage = wafer.stages[stage_index]
                cursor = max(
                    self.current_time,
                    station.door_busy_until,
                    station.transfer_busy_until,
                    station.environment_busy_until,
                    slot.busy_until,
                )
                if (
                    station.door is DoorState.OPEN
                    and not is_doorless_station(station.name)
                ):
                    robot_name = str(stage.in_robot or stage.out_robot or "")
                    duration = (
                        self._durations.place_post(robot_name, station.name)
                        if robot_name
                        else 0.0
                    )
                    self._moves.append({
                        "MoveType": COMPLETE_MOVE,
                        "MoveID": self._next_move_id,
                        "StartTime": cursor,
                        "EndTime": cursor + duration,
                        "ModuleName": station.name,
                        "Station": station.name,
                        "SlotList": [slot_id],
                        "MatIDList": [material.material_id],
                        "PJobName": [material.pjob_name],
                    })
                    self._next_move_id += 1
                    cursor += duration
                    station.door = DoorState.CLOSED
                    station.door_busy_until = cursor
                automatic_moves: list[dict] = []
                self._append_automatic_service(
                    automatic_moves,
                    stage,
                    station,
                    slot_id,
                    material,
                    cursor,
                    stage_index,
                )
                self._moves.extend(automatic_moves)
                self._next_move_id += len(automatic_moves)
                service_end = max(
                    (
                        float(move.get("EndTime") or cursor)
                        for move in automatic_moves
                    ),
                    default=cursor,
                )
                slot.phase = SlotPhase.COMPLETED
                slot.busy_until = max(slot.busy_until, service_end)
                if isinstance(station, LoadLockState) and automatic_moves:
                    station.environment = str(
                        automatic_moves[-1].get(
                            "CurState",
                            station.environment,
                        )
                    )
                    station.environment_busy_until = max(
                        station.environment_busy_until,
                        service_end,
                    )

    def _periodic_clean_due_stage(
        self,
        material: MaterialState,
        station_name: str,
    ) -> Optional[Stage]:
        """返回物料离开指定 PM 时即将触发的周期清洁工序。"""
        wafer = self._wafer_by_material.get(material.material_id)
        if wafer is None:
            return None
        stage_index = self._stage_index(wafer, material, station_name)
        if stage_index >= len(wafer.stages):
            return None
        stage = wafer.stages[stage_index]
        if (
            stage.stage_type != "process"
            or float(stage.clean_time) <= TIME_TOLERANCE
            or int(stage.clean_trigger) <= 0
        ):
            return None
        key = (
            wafer.pjob_name,
            station_name,
            int(stage.slot) + FIRST_SLOT_ID,
        )
        legacy_key = (station_name, int(stage.slot) + FIRST_SLOT_ID)
        next_visits = self._process_visits.get(
            key,
            self._process_visits.get(legacy_key, 0),
        ) + 1
        return (
            stage
            if next_visits % int(stage.clean_trigger) == 0
            else None
        )

    def _material_waits_for_pending_clean(
        self,
        material: MaterialState,
    ) -> bool:
        """判断 LoadLock 中的待加工片是否应留置，等待下一目标 PM 清洁。"""
        wafer = self._wafer_by_material.get(material.material_id)
        if wafer is None:
            return False
        location = self._material_locations().get(material.material_id)
        if location is None:
            return False
        stage_index = self._stage_index(wafer, material, location[1])
        if stage_index >= len(wafer.stages) - 1:
            return False
        following = wafer.stages[stage_index + 1]
        if following.stage_type != "process":
            return False
        station = self.state.stations.get(str(following.chamber))
        if station is None:
            return False
        slot_id = int(following.slot) + FIRST_SLOT_ID
        slot = station.slots.get(slot_id)
        if slot is None:
            return False
        if slot.material is not None:
            return (
                self._periodic_clean_due_stage(
                    slot.material,
                    station.name,
                )
                is not None
            )
        return (
            slot.phase is SlotPhase.CLEANED
            and float(slot.busy_until) > self.current_time + TIME_TOLERANCE
        )

    def _schedule_departure_cleaning(
        self,
        wafer: Wafer,
        stage_index: int,
        station_name: Optional[str],
    ) -> None:
        """记录一次离腔，并按 Wac、PostClean 的顺序追加边界清洁。"""
        if not station_name or stage_index >= len(wafer.stages):
            return
        stage = wafer.stages[stage_index]
        if wafer.pjob_name in self.task.dummy_owner:
            product_pjob = self.task.dummy_owner[wafer.pjob_name]
            for clean in _matching_specs(
                self.task.dummy_wac,
                product_pjob,
                station_name,
            ):
                self._schedule_empty_clean(
                    station_name,
                    float(clean.time),
                    recipe=str(clean.recipe or ""),
                )
        if stage.stage_type != "process":
            return
        key = (
            wafer.pjob_name,
            station_name,
            int(stage.slot) + FIRST_SLOT_ID,
        )
        visits = self._process_visits.get(key, 0) + 1
        self._process_visits[key] = visits
        if (
            float(stage.clean_time) > TIME_TOLERANCE
            and int(stage.clean_trigger) > 0
            and visits % int(stage.clean_trigger) == 0
        ):
            self._schedule_empty_clean(
                station_name,
                float(stage.clean_time),
                recipe=str(stage.clean_recipe or ""),
            )

        remaining_key = (wafer.pjob_name, station_name)
        remaining = max(
            0,
            self._remaining_process_visits.get(remaining_key, 1) - 1,
        )
        self._remaining_process_visits[remaining_key] = remaining
        if remaining != 0 or remaining_key in self._post_cleaned:
            return
        for clean in _matching_specs(
            self.task.post_clean,
            wafer.pjob_name,
            station_name,
        ):
            self._schedule_empty_clean(
                station_name,
                float(clean.time),
                recipe=str(clean.recipe or ""),
            )
        self._post_cleaned.add(remaining_key)

    def _schedule_periodic_cleaning(
        self,
        action: RobotAction,
        committed_moves: Sequence[Mapping[str, Any]],
    ) -> None:
        """统计普通搬运和 Swap 换出片，并安排对应的离腔清洁。"""
        wafer = next(
            (
                item
                for item in self.task.wafers
                if int(item.wid) == int(action.wafer_id)
            ),
            None,
        )
        # 只有本动作真实执行了源站 Pick 才计一次离腔。Swap/LoadLock exchange
        # 换出的物料随后仍在 Robot 手上，后续放片动作不能重复计数。
        primary_material_id = action.material_ids[0]
        primary_departed_source = any(
            move.get("MoveType") == PICK_MOVE
            and primary_material_id in (move.get("MatIDList") or [])
            and action.source_station
            in {
                str(station)
                for station in (move.get("SrcStationList") or [])
            }
            for move in committed_moves
        )
        if wafer is not None and primary_departed_source:
            self._schedule_departure_cleaning(
                wafer,
                action.stage_index,
                action.source_station,
            )
        if action.kind != "swap" or len(action.material_ids) < 2:
            return
        outgoing_id = action.material_ids[1]
        outgoing_wafer = self._wafer_by_material.get(outgoing_id)
        outgoing_location = self._material_locations().get(outgoing_id)
        if outgoing_wafer is None or outgoing_location is None:
            return
        outgoing_material = outgoing_location[3]
        outgoing_stage_index = self._stage_index(
            outgoing_wafer,
            outgoing_material,
            action.destination_station,
        )
        self._schedule_departure_cleaning(
            outgoing_wafer,
            outgoing_stage_index,
            action.destination_station,
        )

    def _related_robot_type(self, robot_name: str) -> int:
        """返回 MoveList 使用的大气侧或真空侧 Robot 类型。"""
        return (
            RELATED_ROBOT_ATMOSPHERE
            if robot_name in self._durations.atm_robots
            else RELATED_ROBOT_VACUUM
        )

    def _is_done(self) -> bool:
        """判断所有已知任务物料是否位于 Route 终点。"""
        locations = self._material_locations()
        for material_id, wafer in self._wafer_by_material.items():
            location = locations.get(material_id)
            if location is None:
                return False
            if self._stage_index(wafer, location[3], location[1]) < len(wafer.stages) - 1:
                return False
        return True

    def _close_orphan_doors(self) -> None:
        """在终态为没有后继意图的开门站补关门动作。"""
        for station in self.state.stations.values():
            if is_doorless_station(station.name) or station.door is DoorState.CLOSED:
                continue
            start = max(
                self.current_time,
                station.door_busy_until,
                station.transfer_busy_until,
            )
            duration = max(
                (
                    self._durations.pick_post(robot.name, station.name)
                    for robot in self.state.robots.values()
                    if not robot.scope or station.name in robot.scope
                ),
                default=0.0,
            )
            self._moves.append(
                {
                    "MoveType": COMPLETE_MOVE,
                    "MoveID": self._next_move_id,
                    "StartTime": start,
                    "EndTime": start + duration,
                    "ModuleName": station.name,
                    "Station": station.name,
                    "SlotList": [FIRST_SLOT_ID],
                    "MatIDList": [],
                }
            )
            self._next_move_id += 1
            station.door = DoorState.CLOSED
            station.door_busy_until = start + duration

    def _deadlock_message(self) -> str:
        """生成包含物料位置和阶段的可诊断死锁信息。"""
        pending = []
        for material_id, wafer in self._wafer_by_material.items():
            location = self._material_locations().get(material_id)
            if location is None:
                pending.append(f"{material_id}:missing")
                continue
            stage = self._stage_index(wafer, location[3], location[1])
            if stage < len(wafer.stages) - 1:
                pending.append(
                    f"{material_id}:{location[1]}#{location[2]}@step{stage}"
                )
        return f"Machine 无可执行搬运意图：{pending[:12]}"


__all__ = [
    "Machine",
    "MachineDeadlockError",
    "MachineRunResult",
    "MachineSelector",
    "MachineSnapshot",
    "MaterialView",
    "RobotAction",
    "RobotView",
    "StaleRobotActionError",
    "StationView",
    "UnknownRobotActionError",
]
