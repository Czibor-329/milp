"""本地调度策略与 ``Machine`` 搬运候选之间的兼容层。

本模块将 Machine 的公开快照和 ``RobotAction`` 映射成既有策略特征所需的
``_DecodeState``/``_Cand`` 等价视图，从而保持 Neural 与 RL checkpoint 的
schema 和特征维度不变。策略只负责候选排序，不读取门、压力或 MoveList。
"""

from __future__ import annotations

from collections import namedtuple
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence

import numpy as np

from src.parse.model import Durations, Problem
from src.schedule.heuristic_config import (
    HEURISTIC_CONFIG_PORTFOLIO,
    HeuristicMachineConfig,
    LEGACY_HEURISTIC_CONFIG,
)
from src.schedule.objectives import (
    ScheduleObjectiveConfig,
    evaluate_schedule_objectives,
    schedule_objective_key,
)
from src.timing.solve import SolveResult
from src.validation.move_fields import PICK_MOVE, PLACE_MOVE, SWAP_MOVE
from src.validation.state import (
    Machine,
    MachineDeadlockError,
    MachineSnapshot,
    MachineState,
    RobotAction,
)


MAKESPAN_TOLERANCE = 1e-6


_Candidate = namedtuple("_Candidate", "wid j dest rob start")


@dataclass
class _PolicyState:
    """保持既有候选特征访问字段的只读兼容状态。"""

    ir: Problem
    tm: Durations
    wmap: Dict[int, Any]
    K: Dict[int, int]
    pos: Dict[int, int]
    occ: Dict[tuple[str, int], int]
    resv: Dict[tuple[str, int], int]
    place_t: Dict[int, float]
    robot_free: Dict[str, float]
    placed: int
    total: int
    reserve: bool
    ch_used: Dict[str, int]
    route_released: Dict[str, int]
    route_wip: Dict[str, int]


def _policy_inputs(
    problem: Problem,
    state: MachineSnapshot,
    actions: Sequence[RobotAction],
) -> tuple[_PolicyState, list[_Candidate]]:
    """把公开 Machine 决策点转换成旧 checkpoint 的输入口径。"""
    wmap = {int(wafer.wid): wafer for wafer in problem.wafers}
    by_material = {wafer.mat_id: wafer for wafer in problem.wafers}
    positions: Dict[int, int] = {}
    occupancy: Dict[tuple[str, int], int] = {}
    place_times: Dict[int, float] = {}
    chamber_usage: Dict[str, int] = {}
    route_released: Dict[str, int] = {}
    route_wip: Dict[str, int] = {}
    for material_id, material in state.materials.items():
        wafer = by_material.get(material_id)
        if wafer is None:
            continue
        step_id = int(material.step_id or 0)
        positions[int(wafer.wid)] = step_id
        place_times[int(wafer.wid)] = max(
            state.time,
            float(material.ready_at)
            - max(float(wafer.stages[step_id].proc), 0.0),
        )
        if step_id > 0 or wafer.already_released:
            route_released[wafer.route_name] = (
                route_released.get(wafer.route_name, 0) + 1
            )
        if (step_id > 0 or wafer.already_released) and step_id < len(wafer.stages) - 1:
            route_wip[wafer.route_name] = route_wip.get(wafer.route_name, 0) + 1
        if material.location in problem.chambers:
            stage = wafer.stages[step_id]
            if stage.stage_type not in {"source", "sink"}:
                occupancy[(material.location, material.slot_id - 1)] = int(wafer.wid)
            chamber_usage[material.location] = chamber_usage.get(material.location, 0) + 1
    for wafer in problem.wafers:
        positions.setdefault(int(wafer.wid), 0)
        place_times.setdefault(int(wafer.wid), state.time)
    compatibility_state = _PolicyState(
        ir=problem,
        tm=Durations(problem),
        wmap=wmap,
        K={int(wafer.wid): len(wafer.stages) - 1 for wafer in problem.wafers},
        pos=positions,
        occ=occupancy,
        resv={},
        place_t=place_times,
        robot_free={
            robot_name: float(robot.ready_at)
            for robot_name, robot in state.robots.items()
        },
        placed=sum(positions.values()),
        total=sum(max(len(wafer.stages) - 1, 0) for wafer in problem.wafers),
        reserve=False,
        ch_used=chamber_usage,
        route_released=route_released,
        route_wip=route_wip,
    )
    candidates = [
        _Candidate(
            action.wafer_id,
            action.stage_index,
            (action.destination_station, action.destination_slot - 1),
            action.robot,
            action.earliest_start,
        )
        for action in actions
    ]
    return compatibility_state, candidates


class HeuristicMachineSelector:
    """按节拍、驻留风险和交换收益选择搬运意图。

    ``Machine`` 同时保留单向送片与 LoadLock 交换候选。本策略决定是否继续
    投料：若一条送片事务结束前已经有 PM 晶圆需要离腔，则先安排出片，避免
    短加工、多并行腔室场景把真空区堆满后触发驻留超时。
    """

    def __init__(
        self,
        problem: Problem | None = None,
        config: HeuristicMachineConfig | None = None,
        *,
        prefer_loadlock_parking: bool = False,
        temporal_lookahead: bool = False,
    ) -> None:
        """保存参数配置，并选择原子交换或 LoadLock 停片平局偏好。"""
        self.problem = problem
        self.config = config or LEGACY_HEURISTIC_CONFIG
        self.prefer_loadlock_parking = bool(prefer_loadlock_parking)
        self.temporal_lookahead = bool(temporal_lookahead)
        self._wafer_by_id = (
            {int(wafer.wid): wafer for wafer in problem.wafers}
            if problem is not None
            else {}
        )
        self._wafer_by_material = (
            {wafer.mat_id: wafer for wafer in problem.wafers}
            if problem is not None
            else {}
        )
        self._route_names = sorted({
            wafer.route_name for wafer in problem.wafers
        }) if problem is not None else []

    def choose(
        self,
        state: MachineSnapshot,
        actions: Sequence[RobotAction],
    ) -> str:
        """返回确定性的节拍感知首选动作。"""
        residency_limited_departures = [
            action
            for action in actions
            if self._current_stage_type(action) == "process"
            and action.residency_deadline is not None
        ]
        earliest_process_departure = min(
            (
                action.earliest_start
                for action in residency_limited_departures
            ),
            default=float("inf"),
        )

        def priority(action: RobotAction) -> tuple:
            """计算一个候选的驻留风险、流向收益和稳定业务顺序。"""
            current_type = self._current_stage_type(action)
            following_type = self._following_stage_type(action)
            is_process_departure = current_type == "process"
            blocks_ready_output = (
                action.flow_kind == "feed"
                and earliest_process_departure
                <= action.projected_ready_time
            )
            residency_slack = (
                float(action.residency_deadline) - action.earliest_start
                if action.residency_deadline is not None
                else float("inf")
            )
            flow_priority = (
                0
                if (
                    action.kind == "ll_park"
                    and self.prefer_loadlock_parking
                )
                else 1
                if action.kind == "ll_exchange"
                else 2
                if is_process_departure
                else 3
                if following_type == "process"
                else 4
                if action.flow_kind == "drain"
                else 5
                if following_type == "sink"
                else 7
                if action.flow_kind == "feed"
                else 6
            )
            return (
                1 if blocks_ready_output else 0,
                min(residency_slack, 0.0),
                action.earliest_start,
                flow_priority,
                residency_slack,
                action.finish_time,
                -action.stage_index,
                action.wafer_id,
                action.destination_station,
            )

        selected = min(actions, key=priority) if self.config.legacy_priority else min(
            actions,
            key=lambda action: self._parametric_priority(
                state,
                actions,
                action,
                earliest_process_departure,
            ),
        )
        return selected.action_id

    def _parametric_priority(
        self,
        state: MachineSnapshot,
        actions: Sequence[RobotAction],
        action: RobotAction,
        earliest_process_departure: float,
    ) -> tuple:
        """用配置权重计算无量纲候选分数，并附加确定性平局规则。"""
        config = self.config
        earliest_values = [float(candidate.earliest_start) for candidate in actions]
        finish_values = [float(candidate.finish_time) for candidate in actions]

        def normalize(value: float, values: Sequence[float]) -> float:
            """在一个决策点内做稳定的零到一归一化。"""
            low = min(values)
            span = max(values) - low
            return 0.0 if span <= 1e-9 else (value - low) / span

        current_type = self._current_stage_type(action)
        following_type = self._following_stage_type(action)
        is_process_departure = current_type == "process"
        residency_slack = (
            float(action.residency_deadline) - float(action.earliest_start)
            if action.residency_deadline is not None
            else float("inf")
        )
        finite_slacks = [
            float(candidate.residency_deadline) - float(candidate.earliest_start)
            for candidate in actions
            if candidate.residency_deadline is not None
        ]
        slack_scale = max(
            [abs(value) for value in finite_slacks]
            + [config.residency_guard_seconds, 1.0]
        )
        normalized_slack = (
            min(max(residency_slack / slack_scale, -1.0), 1.0)
            if residency_slack != float("inf")
            else 1.0
        )
        decision_floor = min(earliest_values)
        departure_in_guard_horizon = (
            float(action.earliest_start)
            <= decision_floor + config.residency_guard_seconds
        )
        urgent_residency = (
            action.residency_deadline is not None
            and residency_slack <= config.residency_guard_seconds
            and (
                not self.temporal_lookahead
                or departure_in_guard_horizon
            )
        )
        blocks_ready_output = (
            action.flow_kind == "feed"
            and earliest_process_departure
            <= float(action.projected_ready_time)
            + config.feed_block_margin_seconds
        )
        downstream_residency_delay = (
            self._downstream_residency_delay(state, action)
            if self.temporal_lookahead
            else 0.0
        )
        blocks_downstream_residency = downstream_residency_delay > 1e-9

        route_balance = self._route_balance(state, action)
        maximum_stage = max(
            (candidate.stage_index for candidate in actions),
            default=0,
        )
        stage_progress = (
            float(action.stage_index) / maximum_stage
            if maximum_stage > 0
            else 0.0
        )
        flow_score = (
            - config.exchange_bonus * float(action.kind == "ll_exchange")
            - config.process_departure_bonus * float(is_process_departure)
            - config.into_process_bonus * float(following_type == "process")
            - config.drain_bonus * float(action.flow_kind == "drain")
            - config.sink_bonus * float(following_type == "sink")
            + config.feed_penalty * float(action.flow_kind == "feed")
        )
        if config.priority_mode == "lexicographic":
            bucket_width = config.earliest_start_bucket_seconds
            earliest_start = float(action.earliest_start)
            time_bucket = (
                int((earliest_start - min(earliest_values)) / bucket_width)
                if bucket_width > 1e-9
                else earliest_start
            )
            return (
                int(blocks_ready_output),
                min(residency_slack, 0.0),
                0 if urgent_residency else 1,
                int(blocks_downstream_residency),
                downstream_residency_delay,
                time_bucket,
                flow_score,
                config.route_balance_weight * route_balance,
                earliest_start,
                residency_slack,
                float(action.finish_time),
                -int(action.stage_index),
                int(action.wafer_id),
                str(action.destination_station),
            )

        score = (
            config.feed_block_penalty * float(blocks_ready_output)
            + config.feed_block_penalty * float(blocks_downstream_residency)
            - config.residency_urgency_bonus * float(urgent_residency)
            + config.residency_slack_weight * normalized_slack
            + config.earliest_start_weight
            * normalize(float(action.earliest_start), earliest_values)
            + config.finish_time_weight
            * normalize(float(action.finish_time), finish_values)
            + flow_score
            + config.route_balance_weight * route_balance
            - config.stage_progress_bonus * stage_progress
        )
        return (
            score,
            float(action.earliest_start),
            float(action.finish_time),
            -int(action.stage_index),
            int(action.wafer_id),
            str(action.destination_station),
        )

    def _downstream_residency_delay(
        self,
        state: MachineSnapshot,
        action: RobotAction,
    ) -> float:
        """估算现在进入上游 PM 会超出下一并行 PM 可接片窗口的时长。

        Machine 会把目标加工完成时刻投影到 ``projected_ready_time``。若该目标
        PM 带驻留上限、下一工序仍是 process，只有下一候选 PM 在驻留截止前
        可用时才应立即开工；否则应先处理其他安全动作，形成 JIT 入腔顺序。
        最终可行性仍由完整定时图判定，本估算只改变离散候选顺序。
        """
        wafer = self._wafer_by_id.get(int(action.wafer_id))
        destination_index = int(action.stage_index) + 1
        following_index = destination_index + 1
        if (
            wafer is None
            or following_index >= len(wafer.stages)
        ):
            return 0.0
        destination = wafer.stages[destination_index]
        following = wafer.stages[following_index]
        if (
            destination.stage_type != "process"
            or float(destination.residency) <= 0.0
            or following.stage_type != "process"
        ):
            return 0.0
        candidates = tuple(following.cands or [following.chamber])
        ready_times: list[float] = []
        for chamber_name in candidates:
            station = state.stations.get(str(chamber_name))
            if station is None:
                continue
            occupied = any(
                material_id is not None
                for material_id in station.slots.values()
            )
            ready_times.append(
                float(station.ready_at)
                if occupied
                else float(state.time)
            )
        if not ready_times:
            return 0.0
        downstream_ready = min(ready_times)
        latest_safe_departure = (
            float(action.projected_ready_time)
            + float(destination.residency)
        )
        return max(downstream_ready - latest_safe_departure, 0.0)

    def _route_balance(
        self,
        state: MachineSnapshot,
        action: RobotAction,
    ) -> float:
        """返回候选 route 的已发片数/配额，仅对 feed 动作施加价格。"""
        if action.flow_kind != "feed" or not self._route_names:
            return 0.0
        released = {route: 0 for route in self._route_names}
        for material in state.materials.values():
            wafer = self._wafer_by_material.get(material.material_id)
            if wafer is None:
                continue
            if int(material.step_id or 0) > 0 or wafer.already_released:
                released[wafer.route_name] = released.get(wafer.route_name, 0) + 1
        wafer = self._wafer_by_id.get(int(action.wafer_id))
        if wafer is None:
            return 0.0
        route_index = self._route_names.index(wafer.route_name)
        quotas = self.config.route_quota_pattern
        quota = float(quotas[route_index]) if route_index < len(quotas) else 1.0
        ratios = []
        for index, route in enumerate(self._route_names):
            route_quota = float(quotas[index]) if index < len(quotas) else 1.0
            ratios.append(float(released.get(route, 0)) / route_quota)
        maximum = max(ratios, default=0.0)
        if maximum <= 1e-9:
            return 0.0
        return (float(released.get(wafer.route_name, 0)) / quota) / maximum

    def _current_stage_type(self, action: RobotAction) -> str:
        """返回候选主晶圆当前工序类型。"""
        wafer = self._wafer_by_id.get(int(action.wafer_id))
        if wafer is None or action.stage_index >= len(wafer.stages):
            return ""
        return str(wafer.stages[action.stage_index].stage_type)

    def _following_stage_type(self, action: RobotAction) -> str:
        """返回候选主晶圆下一工序类型。"""
        wafer = self._wafer_by_id.get(int(action.wafer_id))
        next_index = action.stage_index + 1
        if wafer is None or next_index >= len(wafer.stages):
            return ""
        return str(wafer.stages[next_index].stage_type)


class NeuralMachineSelector:
    """使用现有 SetAttentionNetwork checkpoint 排序 Machine 候选。"""

    def __init__(self, problem: Problem, network: Any) -> None:
        self.problem = problem
        self.network = network
        from src.schedule.neural import _feature_context

        self.context = _feature_context(problem)
        self.decision_count = 0

    def choose(
        self,
        state: MachineSnapshot,
        actions: Sequence[RobotAction],
    ) -> str:
        """按既有候选特征维度和网络分数选择动作。"""
        if len(actions) == 1:
            return actions[0].action_id
        from src.schedule.neural import _candidate_features

        policy_state, candidates = _policy_inputs(self.problem, state, actions)
        scores = self.network.score(
            _candidate_features(policy_state, candidates, self.context)
        )
        self.decision_count += 1
        index = min(
            range(len(actions)),
            key=lambda item: (
                -float(scores[item]),
                0 if actions[item].kind == "ll_exchange" else 1,
                actions[item].earliest_start,
                actions[item].wafer_id,
                actions[item].destination_station,
            ),
        )
        return actions[index].action_id


class E2ECTQMachineSelector:
    """使用端到端资源流图策略选择唯一在线轨迹。"""

    def __init__(self, problem: Problem, policy: Any) -> None:
        """缓存静态资源流上下文，不在每个事件重复扫描完整 Recipe。"""
        from src.schedule.e2e_ctq import build_resource_flow_context

        self.problem = problem
        self.policy = policy
        self.context = build_resource_flow_context(problem)
        self.decision_count = 0
        self.quantile_evaluations = 0

    def choose(
        self,
        state: MachineSnapshot,
        actions: Sequence[RobotAction],
    ) -> str:
        """对当前全部合法联合动作做一次前向并确定性选取。"""
        if len(actions) == 1:
            return actions[0].action_id
        from src.schedule.e2e_ctq import build_resource_flow_observation

        observation = build_resource_flow_observation(
            self.problem,
            state,
            actions,
            self.context,
        )
        logits, quantiles = self.policy.score(observation)
        self.decision_count += 1
        self.quantile_evaluations += int(quantiles.size)
        index = min(
            range(len(actions)),
            key=lambda item: (
                -float(logits[item]),
                float(np.mean(quantiles[item])),
                float(actions[item].earliest_start),
                int(actions[item].wafer_id),
                int(actions[item].stage_index),
                str(actions[item].destination_station),
                int(actions[item].destination_slot),
            ),
        )
        return actions[index].action_id


class SetRankMachineSelector(HeuristicMachineSelector):
    """用逐实例 SetRank 网络选择一套参数，再执行参数化启发式。"""

    def __init__(self, problem: Problem, policy: Any) -> None:
        """预测一次静态配置，并保存可观测的配置名称。"""
        ranked = policy.rank(problem, HEURISTIC_CONFIG_PORTFOLIO)
        if not ranked:
            raise ValueError("SetRank-PIAC 没有返回可用配置")
        config = HEURISTIC_CONFIG_PORTFOLIO[ranked[0]]
        super().__init__(problem, config)
        self.predicted_order = [
            HEURISTIC_CONFIG_PORTFOLIO[index].name for index in ranked
        ]
        self.selected_config = config.name


class RlMachineSelector:
    """使用现有 RL/BC ``score_step`` checkpoint 排序 Machine 候选。"""

    def __init__(
        self,
        problem: Problem,
        policy: Any,
        *,
        rng: Any = None,
        temperature: float = 0.7,
    ) -> None:
        self.problem = problem
        self.policy = policy
        self.rng = rng
        self.temperature = float(temperature)

    def choose(
        self,
        state: MachineSnapshot,
        actions: Sequence[RobotAction],
    ) -> str:
        """按原 25 维 step feature 贪心或带 Gumbel 噪声选择动作。"""
        if len(actions) == 1:
            return actions[0].action_id
        from src.schedule.features import step_features

        policy_state, candidates = _policy_inputs(self.problem, state, actions)
        scores = np.asarray(
            self.policy.score_step(step_features(policy_state, candidates)),
            dtype=np.float64,
        )
        if self.rng is not None:
            scores = scores / self.temperature + self.rng.gumbel(size=len(scores))
        index = min(
            range(len(actions)),
            key=lambda item: (
                -float(scores[item]),
                actions[item].earliest_start,
                actions[item].wafer_id,
            ),
        )
        return actions[index].action_id


def _schedule_rows(
    problem: Problem,
    moves: Sequence[Mapping[str, Any]],
    current_time: float,
) -> Dict[int, list[tuple[str, str, float, float]]]:
    """从 Machine MoveList 合成兼容 ``SolveResult.schedule`` 的工序行。"""
    rows: Dict[int, list[list[Any]]] = {
        int(wafer.wid): [
            [
                stage.stage_type,
                stage.chamber,
                float(current_time if index == 0 else 0.0),
                float(current_time if index == 0 else 0.0),
            ]
            for index, stage in enumerate(wafer.stages)
        ]
        for wafer in problem.wafers
    }
    wafer_by_material = {wafer.mat_id: wafer for wafer in problem.wafers}
    current_step = {wafer.mat_id: 0 for wafer in problem.wafers}
    for move in sorted(
        moves,
        key=lambda item: (
            float(item.get("StartTime") or 0.0),
            int(item.get("MoveID") or 0),
        ),
    ):
        material_ids = list(move.get("MatIDList") or [])
        if not material_ids:
            continue
        material_id = material_ids[0]
        wafer = wafer_by_material.get(material_id)
        if wafer is None:
            continue
        if move.get("MoveType") == 0:
            step = current_step[material_id]
            rows[int(wafer.wid)][step][3] = float(move.get("StartTime") or 0.0)
        elif move.get("MoveType") == 1:
            raw_step = move.get("StepID")
            step = (
                int(raw_step)
                if isinstance(raw_step, int)
                else min(current_step[material_id] + 1, len(wafer.stages) - 1)
            )
            destination = str((move.get("DestStationList") or [wafer.stages[step].chamber])[0])
            rows[int(wafer.wid)][step][1] = destination
            rows[int(wafer.wid)][step][2] = float(move.get("EndTime") or 0.0)
            current_step[material_id] = step
    normalized: Dict[int, list[tuple[str, str, float, float]]] = {}
    for wafer in problem.wafers:
        wafer_rows = rows[int(wafer.wid)]
        for index, row in enumerate(wafer_rows):
            if index == len(wafer_rows) - 1:
                row[3] = row[2]
            elif row[3] < row[2]:
                row[3] = row[2]
        normalized[int(wafer.wid)] = [tuple(row) for row in wafer_rows]  # type: ignore[list-item]
    return normalized


def schedule_with_machine(
    problem: Problem,
    selector: Any,
    *,
    initial_state: "MachineState | Mapping[str, Any] | None" = None,
    current_time: float = 0.0,
    initial_move_id: int = 0,
    allow_loadlock_exchange: bool = True,
) -> SolveResult:
    """运行 Machine 并返回保持旧接口兼容的 ``SolveResult``。

    ``allow_loadlock_exchange`` 只控制候选是否可见；是否实际选择交换仍由
    ``selector`` 决定。
    """
    machine = Machine(
        problem,
        initial_state,
        current_time=current_time,
        initial_move_id=initial_move_id,
        allow_loadlock_exchange=allow_loadlock_exchange,
    )
    run_result = machine.run(selector)
    moves = [dict(move) for move in run_result.moves]
    result = SolveResult(
        status=0,
        makespan=run_result.makespan,
        schedule=_schedule_rows(problem, moves, current_time),
        releases=[],
        machine_moves=moves,
        machine_result=run_result,
        machine=machine,
    )
    result.feasible = True  # type: ignore[attr-defined]
    return result


def _total_robot_holding_time(moves: Sequence[Mapping[str, Any]]) -> float:
    """统计晶圆从进入 Robot 手槽到离手之间的总时间。"""
    acquired_at: Dict[Any, float] = {}
    total = 0.0
    for move in sorted(
        moves,
        key=lambda item: (
            float(item.get("StartTime") or 0.0),
            int(item.get("MoveID") or 0),
        ),
    ):
        move_type = move.get("MoveType")
        if move_type == PICK_MOVE:
            for material_id in move.get("MatIDList") or []:
                acquired_at[material_id] = float(move.get("EndTime") or 0.0)
        elif move_type == PLACE_MOVE:
            for material_id in move.get("MatIDList") or []:
                start = acquired_at.pop(material_id, None)
                if start is not None:
                    total += max(float(move.get("EndTime") or 0.0) - start, 0.0)
        elif move_type == SWAP_MOVE:
            end = float(move.get("EndTime") or 0.0)
            for material_id in move.get("SendMatList") or []:
                start = acquired_at.pop(material_id, None)
                if start is not None:
                    total += max(end - start, 0.0)
            for material_id in move.get("RecvMatList") or []:
                acquired_at[material_id] = end
    return total


def schedule_heuristic_with_machine(
    problem: Problem,
    *,
    config: HeuristicMachineConfig | None = None,
    objectives: ScheduleObjectiveConfig | None = None,
    initial_state: "MachineState | Mapping[str, Any] | None" = None,
    current_time: float = 0.0,
    initial_move_id: int = 0,
    allow_loadlock_exchange: bool = True,
) -> SolveResult:
    """按可选多指标目标选择启发式方案。

    未启用 ``objectives`` 时严格保留原行为：以 makespan 为主目标、Robot
    持片时间为次目标，在原子 LoadLock 交换与停片方案之间取优。

    启用目标时会评估启发式参数组合和一个 LoadLock 停片变体，先减少真实
    驻留超限，再尽量达到三个前端目标，最后比较 makespan。目标无法全部
    达到时仍返回相对偏差最小的可执行候选。
    """
    objective_config = objectives or ScheduleObjectiveConfig()

    if objective_config.enabled:
        configurations = (
            (config,)
            if config is not None
            else HEURISTIC_CONFIG_PORTFOLIO
        )
        candidates: list[SolveResult] = []
        candidate_labels: list[tuple[str, bool]] = []
        for candidate_config in configurations:
            try:
                candidate = schedule_with_machine(
                    problem,
                    HeuristicMachineSelector(problem, candidate_config),
                    initial_state=initial_state,
                    current_time=current_time,
                    initial_move_id=initial_move_id,
                    allow_loadlock_exchange=(
                        allow_loadlock_exchange
                        and candidate_config.allow_loadlock_exchange
                    ),
                )
            except (MachineDeadlockError, RuntimeError, TypeError, ValueError):
                continue
            candidates.append(candidate)
            candidate_labels.append((candidate_config.name, False))

        parking_config = config or LEGACY_HEURISTIC_CONFIG
        try:
            parked = schedule_with_machine(
                problem,
                HeuristicMachineSelector(
                    problem,
                    parking_config,
                    prefer_loadlock_parking=True,
                ),
                initial_state=initial_state,
                current_time=current_time,
                initial_move_id=initial_move_id,
                allow_loadlock_exchange=allow_loadlock_exchange,
            )
            candidates.append(parked)
            candidate_labels.append((parking_config.name, True))
        except (MachineDeadlockError, RuntimeError, TypeError, ValueError):
            pass

        if not candidates:
            raise MachineDeadlockError("多指标启发式没有找到可执行候选")
        metrics = [
            evaluate_schedule_objectives(
                problem,
                candidate.machine_moves or [],
                objective_config,
            )
            for candidate in candidates
        ]
        selected_index = min(
            range(len(candidates)),
            key=lambda index: schedule_objective_key(
                metrics[index],
                objective_config,
                float(candidates[index].makespan),
            ),
        )
        selected = candidates[selected_index]
        selected_config, selected_parking = candidate_labels[selected_index]
        selected.heuristic_config = selected_config  # type: ignore[attr-defined]
        selected.prefer_loadlock_parking = selected_parking  # type: ignore[attr-defined]
        selected.objective_metrics = metrics[selected_index].to_dict()  # type: ignore[attr-defined]
        selected.objective_diagnostics = {  # type: ignore[attr-defined]
            "candidateCount": len(candidates),
            "targets": objective_config.to_dict(),
            "metrics": metrics[selected_index].to_dict(),
            "selectedConfig": selected_config,
            "preferLoadLockParking": selected_parking,
        }
        return selected

    # ``config=None`` 保留单参数构造语义，兼容测试和外部调用方注入的 legacy selector。
    baseline_selector = (
        HeuristicMachineSelector(problem)
        if config is None
        else HeuristicMachineSelector(problem, config)
    )
    baseline = schedule_with_machine(
        problem,
        baseline_selector,
        initial_state=initial_state,
        current_time=current_time,
        initial_move_id=initial_move_id,
        allow_loadlock_exchange=allow_loadlock_exchange,
    )
    try:
        parked = schedule_with_machine(
            problem,
            HeuristicMachineSelector(
                problem,
                config,
                prefer_loadlock_parking=True,
            ),
            initial_state=initial_state,
            current_time=current_time,
            initial_move_id=initial_move_id,
            allow_loadlock_exchange=allow_loadlock_exchange,
        )
    except (MachineDeadlockError, RuntimeError, TypeError, ValueError):
        return baseline
    if parked.makespan < baseline.makespan - MAKESPAN_TOLERANCE:
        return parked
    if parked.makespan > baseline.makespan + MAKESPAN_TOLERANCE:
        return baseline
    baseline_holding = _total_robot_holding_time(baseline.machine_moves or [])
    parked_holding = _total_robot_holding_time(parked.machine_moves or [])
    return parked if parked_holding < baseline_holding - MAKESPAN_TOLERANCE else baseline


__all__ = [
    "E2ECTQMachineSelector",
    "HeuristicMachineSelector",
    "NeuralMachineSelector",
    "RlMachineSelector",
    "SetRankMachineSelector",
    "schedule_heuristic_with_machine",
    "schedule_with_machine",
]
