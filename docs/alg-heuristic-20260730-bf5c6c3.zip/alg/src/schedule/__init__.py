"""Heuristic 精简部署包的调度入口。

该包只公开启发式首排和实时重算能力，不导入训练、神经网络、RL 或 MILP
模块，从而保持部署依赖最小化。
"""

from .api import start_schedule
from .realtime import RealtimeRescheduler

__all__ = [
    "RealtimeRescheduler",
    "start_schedule",
]
