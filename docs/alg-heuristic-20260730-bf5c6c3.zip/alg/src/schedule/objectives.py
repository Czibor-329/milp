"""调度结果的多指标统计与目标排序。

本模块只读取 ``Problem`` 和已经生成的 Machine MoveList，不改变设备物理
语义。Heuristic 可用这些统一指标比较多条可执行候选：驻留约束保持最高
优先级，Robot 最大持片时间和晶圆系统停留时间 CV 作为可选目标，最后再
比较 makespan。
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from src.parse.model import Problem
from src.validation.move_fields import (
    PICK_MOVE,
    PLACE_MOVE,
    PREPARE_MOVE,
    PROCESS_MOVE,
    SWAP_MOVE,
)


TIME_TOLERANCE = 1e-6
MINIMUM_NORMALIZATION_SECONDS = 1.0
MINIMUM_NORMALIZATION_CV = 0.01


@dataclass(frozen=True)
class ScheduleObjectiveConfig:
    """描述前端可调的三个调度目标。

    参数:
        residency_guard_seconds: 在 Route 驻留上限内额外预留的安全余量；
            0 表示只使用原始 Route 上限。
        maximum_robot_holding_seconds: 单片晶圆从 Pick 完成到 Place 开始的
            最大目标时长；``None`` 表示不参与选优。
        maximum_system_residence_cv: 晶圆从首次离开源站到最终返回汇站的
            系统停留时间变异系数目标；``None`` 表示不参与选优。
    """

    residency_guard_seconds: float = 0.0
    maximum_robot_holding_seconds: Optional[float] = None
    maximum_system_residence_cv: Optional[float] = None

    def __post_init__(self) -> None:
        """拒绝非有限值或负数，避免目标比较出现静默失效。"""
        values = {
            "residency_guard_seconds": self.residency_guard_seconds,
            "maximum_robot_holding_seconds": self.maximum_robot_holding_seconds,
            "maximum_system_residence_cv": self.maximum_system_residence_cv,
        }
        for name, value in values.items():
            if value is None:
                continue
            if not math.isfinite(float(value)) or float(value) < 0.0:
                raise ValueError(f"{name} 必须是有限非负数")

    @property
    def enabled(self) -> bool:
        """返回是否至少启用了一个会改变候选选优的目标。"""
        return (
            self.residency_guard_seconds > TIME_TOLERANCE
            or self.maximum_robot_holding_seconds is not None
            or self.maximum_system_residence_cv is not None
        )

    def to_dict(self) -> Dict[str, Optional[float]]:
        """转换成供诊断输出使用的稳定 JSON 字段。"""
        return {
            "residencyGuardSeconds": float(self.residency_guard_seconds),
            "maximumRobotHoldingSeconds": self.maximum_robot_holding_seconds,
            "maximumSystemResidenceCv": self.maximum_system_residence_cv,
        }


@dataclass(frozen=True)
class ScheduleObjectiveMetrics:
    """一条完整候选计划对应的三类指标。"""

    residency_violation_count: int
    maximum_residency_overrun_seconds: float
    maximum_residency_guard_excess_seconds: float
    maximum_robot_holding_seconds: float
    system_residence_cv: float
    completed_system_residence_count: int

    def to_dict(self) -> Dict[str, float | int]:
        """转换成前端诊断可直接展示的 camelCase 对象。"""
        return {
            "residencyViolationCount": self.residency_violation_count,
            "maximumResidencyOverrunSeconds": (
                self.maximum_residency_overrun_seconds
            ),
            "maximumResidencyGuardExcessSeconds": (
                self.maximum_residency_guard_excess_seconds
            ),
            "maximumRobotHoldingSeconds": self.maximum_robot_holding_seconds,
            "systemResidenceCv": self.system_residence_cv,
            "completedSystemResidenceCount": (
                self.completed_system_residence_count
            ),
        }


def _time(move: Mapping[str, Any], field: str) -> float:
    """读取 Move 时间字段，缺失时按 0 处理。"""
    return float(move.get(field) or 0.0)


def _station(
    move: Mapping[str, Any],
    list_field: str,
) -> str:
    """优先从站点列表读取单站名称，并兼容模块字段。"""
    stations = move.get(list_field) or []
    if stations:
        return str(stations[0])
    return str(move.get("Station") or move.get("ModuleName") or "")


def _robot(move: Mapping[str, Any]) -> str:
    """返回 Move 使用的 Robot 名称。"""
    return str(move.get("Robot") or move.get("ModuleName") or "")


def _material_ids(
    move: Mapping[str, Any],
    field: str = "MatIDList",
) -> Tuple[Any, ...]:
    """把 Move 的物料字段规范为不可变序列。"""
    return tuple(move.get(field) or ())


def _coefficient_of_variation(values: Sequence[float]) -> float:
    """计算总体标准差除以均值；不足两条完整样本时返回 0。"""
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    if mean <= TIME_TOLERANCE:
        return 0.0
    variance = sum((value - mean) ** 2 for value in values) / len(values)
    return math.sqrt(variance) / mean


def _residency_delays(
    problem: Problem,
    moves: Sequence[Mapping[str, Any]],
) -> list[tuple[float, float]]:
    """返回每次受约束 PM 加工的 ``(实际驻留, Route 上限)``。

    有门站点以 Pick/Swap 的 Prepare 起点作为离腔响应时刻；无门或缺少
    Prepare 的兼容计划退化为 Pick/Swap 起点。
    """
    ordered = sorted(
        moves,
        key=lambda move: (_time(move, "StartTime"), int(move.get("MoveID") or 0)),
    )
    departures: Dict[tuple[Any, str], list[float]] = {}
    for move in ordered:
        move_type = int(move.get("MoveType", -1))
        if move_type == PREPARE_MOVE:
            station_name = _station(move, "StationList")
            material_ids = _material_ids(move)
        elif move_type == PICK_MOVE:
            station_name = _station(move, "SrcStationList")
            material_ids = _material_ids(move)
        elif move_type == SWAP_MOVE:
            station_name = _station(move, "StationList")
            material_ids = _material_ids(move, "RecvMatList")
        else:
            continue
        for material_id in material_ids:
            departures.setdefault((material_id, station_name), []).append(
                _time(move, "StartTime")
            )

    wafer_by_material = {wafer.mat_id: wafer for wafer in problem.wafers}
    process_occurrences: Dict[tuple[Any, str], int] = {}
    used_departures: Dict[tuple[Any, str], int] = {}
    delays: list[tuple[float, float]] = []
    for move in ordered:
        if int(move.get("MoveType", -1)) != PROCESS_MOVE:
            continue
        station_name = _station(move, "StationList")
        process_end = _time(move, "EndTime")
        for material_id in _material_ids(move):
            wafer = wafer_by_material.get(material_id)
            if wafer is None:
                continue
            matching_stages = [
                stage
                for stage in wafer.stages
                if (
                    stage.stage_type == "process"
                    and (
                        stage.chamber == station_name
                        or station_name in stage.cands
                    )
                )
            ]
            event_key = (material_id, station_name)
            occurrence = process_occurrences.get(event_key, 0)
            process_occurrences[event_key] = occurrence + 1
            if occurrence >= len(matching_stages):
                continue
            limit = float(matching_stages[occurrence].residency)
            if limit <= 0.0:
                continue
            departure_index = used_departures.get(event_key, 0)
            candidates = departures.get(event_key, [])
            while (
                departure_index < len(candidates)
                and candidates[departure_index] < process_end - TIME_TOLERANCE
            ):
                departure_index += 1
            if departure_index >= len(candidates):
                delays.append((float("inf"), limit))
                continue
            departure = candidates[departure_index]
            used_departures[event_key] = departure_index + 1
            delays.append((max(departure - process_end, 0.0), limit))
    return delays


def _maximum_robot_holding_seconds(
    moves: Sequence[Mapping[str, Any]],
) -> float:
    """统计单片晶圆 Pick 完成到 Place 开始的最大 Robot 持片时间。"""
    acquired_at: Dict[tuple[str, Any], float] = {}
    maximum = 0.0
    for move in sorted(
        moves,
        key=lambda item: (_time(item, "StartTime"), int(item.get("MoveID") or 0)),
    ):
        move_type = int(move.get("MoveType", -1))
        robot_name = _robot(move)
        if not robot_name:
            continue
        if move_type == PICK_MOVE:
            for material_id in _material_ids(move):
                acquired_at[(robot_name, material_id)] = _time(move, "EndTime")
        elif move_type == PLACE_MOVE:
            for material_id in _material_ids(move):
                started_at = acquired_at.pop((robot_name, material_id), None)
                if started_at is not None:
                    maximum = max(
                        maximum,
                        max(_time(move, "StartTime") - started_at, 0.0),
                    )
        elif move_type == SWAP_MOVE:
            # SwapMove 的 RecvMatList 是 Robot 从目标站取出的晶圆，
            # SendMatList 则是 Robot 原先持有并送入目标站的晶圆。因此，
            # 原持片必须在 Swap 开始时结束，新接收片从 Swap 完成后开始计时。
            for material_id in _material_ids(move, "SendMatList"):
                started_at = acquired_at.pop((robot_name, material_id), None)
                if started_at is not None:
                    maximum = max(
                        maximum,
                        max(_time(move, "StartTime") - started_at, 0.0),
                    )
            for material_id in _material_ids(move, "RecvMatList"):
                acquired_at[(robot_name, material_id)] = _time(move, "EndTime")
    return maximum


def _system_residence_durations(
    problem: Problem,
    moves: Sequence[Mapping[str, Any]],
) -> list[float]:
    """统计晶圆首次离开 Route 源站到最终进入 Route 汇站的完整时长。"""
    boundaries = {
        wafer.mat_id: (
            str(wafer.stages[0].chamber),
            str(wafer.stages[-1].chamber),
        )
        for wafer in problem.wafers
        if wafer.stages
    }
    entries: Dict[Any, float] = {}
    completions: Dict[Any, float] = {}
    for move in sorted(
        moves,
        key=lambda item: (_time(item, "StartTime"), int(item.get("MoveID") or 0)),
    ):
        move_type = int(move.get("MoveType", -1))
        if move_type == PICK_MOVE:
            source = _station(move, "SrcStationList")
            for material_id in _material_ids(move):
                expected = boundaries.get(material_id)
                if expected is not None and source == expected[0]:
                    entries.setdefault(material_id, _time(move, "EndTime"))
        elif move_type == PLACE_MOVE:
            destination = _station(move, "DestStationList")
            for material_id in _material_ids(move):
                expected = boundaries.get(material_id)
                if expected is not None and destination == expected[1]:
                    completions[material_id] = _time(move, "EndTime")
        elif move_type == SWAP_MOVE:
            station_name = _station(move, "StationList")
            for material_id in _material_ids(move, "SendMatList"):
                expected = boundaries.get(material_id)
                if expected is not None and station_name == expected[0]:
                    entries.setdefault(material_id, _time(move, "EndTime"))
            for material_id in _material_ids(move, "RecvMatList"):
                expected = boundaries.get(material_id)
                if expected is not None and station_name == expected[1]:
                    completions[material_id] = _time(move, "EndTime")
    return [
        max(completions[material_id] - entered_at, 0.0)
        for material_id, entered_at in entries.items()
        if (
            material_id in completions
            and completions[material_id] >= entered_at - TIME_TOLERANCE
        )
    ]


def evaluate_schedule_objectives(
    problem: Problem,
    moves: Sequence[Mapping[str, Any]],
    config: ScheduleObjectiveConfig,
) -> ScheduleObjectiveMetrics:
    """按统一口径统计一条候选计划的三个目标指标。"""
    residency_delays = _residency_delays(problem, moves)
    overruns = [
        max(delay - limit, 0.0)
        for delay, limit in residency_delays
    ]
    guard_excesses = [
        max(
            delay - max(limit - config.residency_guard_seconds, 0.0),
            0.0,
        )
        for delay, limit in residency_delays
    ]
    system_durations = _system_residence_durations(problem, moves)
    return ScheduleObjectiveMetrics(
        residency_violation_count=sum(
            overrun > TIME_TOLERANCE for overrun in overruns
        ),
        maximum_residency_overrun_seconds=max(overruns, default=0.0),
        maximum_residency_guard_excess_seconds=max(
            guard_excesses,
            default=0.0,
        ),
        maximum_robot_holding_seconds=_maximum_robot_holding_seconds(moves),
        system_residence_cv=_coefficient_of_variation(system_durations),
        completed_system_residence_count=len(system_durations),
    )


def schedule_objective_key(
    metrics: ScheduleObjectiveMetrics,
    config: ScheduleObjectiveConfig,
    makespan: float,
) -> tuple[float, ...]:
    """生成候选比较键，先满足约束目标，再比较 makespan。

    Route 驻留实际超限始终位于最高优先级。其余已启用目标先比较未达标
    数量，再比较相对超差总量；全部达到后自然退化为 makespan 最短。
    """
    target_excesses: list[float] = []
    if config.residency_guard_seconds > TIME_TOLERANCE:
        target_excesses.append(
            metrics.maximum_residency_guard_excess_seconds
            / max(config.residency_guard_seconds, MINIMUM_NORMALIZATION_SECONDS)
        )
    if config.maximum_robot_holding_seconds is not None:
        target_excesses.append(
            max(
                metrics.maximum_robot_holding_seconds
                - config.maximum_robot_holding_seconds,
                0.0,
            )
            / max(
                config.maximum_robot_holding_seconds,
                MINIMUM_NORMALIZATION_SECONDS,
            )
        )
    if config.maximum_system_residence_cv is not None:
        target_excesses.append(
            max(
                metrics.system_residence_cv
                - config.maximum_system_residence_cv,
                0.0,
            )
            / max(
                config.maximum_system_residence_cv,
                MINIMUM_NORMALIZATION_CV,
            )
        )
    return (
        float(metrics.residency_violation_count),
        float(metrics.maximum_residency_overrun_seconds),
        float(sum(excess > TIME_TOLERANCE for excess in target_excesses)),
        float(sum(target_excesses)),
        float(makespan),
        float(metrics.maximum_robot_holding_seconds),
        float(metrics.system_residence_cv),
    )


__all__ = [
    "ScheduleObjectiveConfig",
    "ScheduleObjectiveMetrics",
    "evaluate_schedule_objectives",
    "schedule_objective_key",
]
