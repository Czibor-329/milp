"""Machine 启发式的可学习参数空间与候选配置组合。

本模块把原先固化在 :class:`HeuristicMachineSelector` 中的派工偏好抽成稳定、
可序列化的配置对象。默认配置继续走原字典序规则；其他配置使用无量纲加权评分，
供逐实例配置网络、上下文老虎机和代理搜索共用。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np


CONFIG_SCHEMA_VERSION = "machine-heuristic-config-v1"
MAX_ROUTE_QUOTAS = 4


@dataclass(frozen=True)
class HeuristicMachineConfig:
    """描述一套 Machine 派工参数。

    所有权重都作用于同一决策点内归一化后的候选特征，数值越小越优。
    ``legacy_priority=True`` 时忽略其余评分权重，严格复现原启发式字典序。
    ``route_quota_pattern`` 按排序后的 route 对齐，超出长度的 route 使用配额 1。
    """

    name: str
    legacy_priority: bool = False
    priority_mode: str = "weighted"
    allow_loadlock_exchange: bool = True
    earliest_start_bucket_seconds: float = 0.0
    feed_block_margin_seconds: float = 0.0
    residency_guard_seconds: float = 0.0
    feed_block_penalty: float = 4.0
    residency_urgency_bonus: float = 2.0
    residency_slack_weight: float = 1.0
    earliest_start_weight: float = 1.0
    finish_time_weight: float = 0.25
    exchange_bonus: float = 1.5
    process_departure_bonus: float = 1.25
    into_process_bonus: float = 1.0
    drain_bonus: float = 0.5
    sink_bonus: float = 0.25
    feed_penalty: float = 0.5
    route_balance_weight: float = 0.5
    stage_progress_bonus: float = 0.1
    route_quota_pattern: Tuple[float, ...] = (1.0,)

    def __post_init__(self) -> None:
        """拒绝无效配置，避免训练标签与在线推理使用不同语义。"""
        if not self.name.strip():
            raise ValueError("启发式配置名称不能为空")
        if self.priority_mode not in {"weighted", "lexicographic"}:
            raise ValueError("priority_mode 只支持 weighted 或 lexicographic")
        if self.earliest_start_bucket_seconds < 0:
            raise ValueError("earliest_start_bucket_seconds 不能为负数")
        if self.feed_block_margin_seconds < 0:
            raise ValueError("feed_block_margin_seconds 不能为负数")
        if self.residency_guard_seconds < 0:
            raise ValueError("residency_guard_seconds 不能为负数")
        if not self.route_quota_pattern:
            raise ValueError("route_quota_pattern 不能为空")
        if any(float(value) <= 0 for value in self.route_quota_pattern):
            raise ValueError("route 配额必须全部为正数")

    def vector(self) -> np.ndarray:
        """返回供神经配置器读取的固定维度无量纲向量。"""
        quotas = [
            float(value)
            for value in self.route_quota_pattern[:MAX_ROUTE_QUOTAS]
        ]
        quotas.extend([1.0] * (MAX_ROUTE_QUOTAS - len(quotas)))
        maximum_quota = max(quotas) or 1.0
        normalized_quotas = [value / maximum_quota for value in quotas]
        return np.asarray([
            float(self.legacy_priority),
            float(self.priority_mode == "lexicographic"),
            float(self.allow_loadlock_exchange),
            self.earliest_start_bucket_seconds / 120.0,
            self.feed_block_margin_seconds / 120.0,
            self.residency_guard_seconds / 120.0,
            self.feed_block_penalty / 8.0,
            self.residency_urgency_bonus / 8.0,
            self.residency_slack_weight / 4.0,
            self.earliest_start_weight / 4.0,
            self.finish_time_weight / 4.0,
            self.exchange_bonus / 4.0,
            self.process_departure_bonus / 4.0,
            self.into_process_bonus / 4.0,
            self.drain_bonus / 4.0,
            self.sink_bonus / 4.0,
            self.feed_penalty / 4.0,
            self.route_balance_weight / 4.0,
            self.stage_progress_bonus / 4.0,
            *normalized_quotas,
        ], dtype=np.float32)


LEGACY_HEURISTIC_CONFIG = HeuristicMachineConfig(
    name="legacy",
    legacy_priority=True,
)


HEURISTIC_CONFIG_PORTFOLIO: Tuple[HeuristicMachineConfig, ...] = (
    LEGACY_HEURISTIC_CONFIG,
    HeuristicMachineConfig(
        name="balanced-flow",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=2.0,
    ),
    HeuristicMachineConfig(
        name="throughput-first",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=10.0,
        earliest_start_weight=0.35,
        finish_time_weight=0.15,
        exchange_bonus=2.0,
        process_departure_bonus=1.6,
        into_process_bonus=1.5,
        drain_bonus=0.3,
        feed_penalty=-0.35,
        route_balance_weight=0.4,
        stage_progress_bonus=0.2,
    ),
    HeuristicMachineConfig(
        name="drain-first",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=5.0,
        feed_block_penalty=6.0,
        residency_urgency_bonus=3.0,
        process_departure_bonus=2.0,
        drain_bonus=1.8,
        feed_penalty=1.4,
        stage_progress_bonus=0.5,
    ),
    HeuristicMachineConfig(
        name="residency-guard-10",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=5.0,
        residency_guard_seconds=10.0,
        feed_block_penalty=6.0,
        residency_urgency_bonus=4.0,
        residency_slack_weight=2.0,
        process_departure_bonus=1.8,
    ),
    HeuristicMachineConfig(
        name="residency-guard-30",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=10.0,
        residency_guard_seconds=30.0,
        feed_block_margin_seconds=10.0,
        feed_block_penalty=7.0,
        residency_urgency_bonus=5.0,
        residency_slack_weight=2.5,
        process_departure_bonus=2.0,
    ),
    HeuristicMachineConfig(
        name="exchange-first",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=5.0,
        exchange_bonus=3.5,
        process_departure_bonus=1.5,
        into_process_bonus=1.2,
        finish_time_weight=0.1,
    ),
    HeuristicMachineConfig(
        name="no-exchange-throughput",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=10.0,
        allow_loadlock_exchange=False,
        earliest_start_weight=0.4,
        process_departure_bonus=1.5,
        into_process_bonus=1.6,
        feed_penalty=-0.25,
    ),
    HeuristicMachineConfig(
        name="completion-first",
        earliest_start_weight=0.6,
        finish_time_weight=1.5,
        process_departure_bonus=1.4,
        drain_bonus=1.0,
        sink_bonus=1.2,
        stage_progress_bonus=0.8,
    ),
    HeuristicMachineConfig(
        name="route-equal",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=10.0,
        route_balance_weight=2.0,
        route_quota_pattern=(1.0, 1.0, 1.0, 1.0),
    ),
    HeuristicMachineConfig(
        name="route-1-2",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=10.0,
        route_balance_weight=2.5,
        route_quota_pattern=(1.0, 2.0, 1.0, 1.0),
    ),
    HeuristicMachineConfig(
        name="route-2-1",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=10.0,
        route_balance_weight=2.5,
        route_quota_pattern=(2.0, 1.0, 1.0, 1.0),
    ),
    HeuristicMachineConfig(
        name="route-1-3",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=15.0,
        route_balance_weight=3.0,
        route_quota_pattern=(1.0, 3.0, 1.0, 1.0),
    ),
    HeuristicMachineConfig(
        name="route-3-1",
        priority_mode="lexicographic",
        earliest_start_bucket_seconds=15.0,
        route_balance_weight=3.0,
        route_quota_pattern=(3.0, 1.0, 1.0, 1.0),
    ),
)


def config_by_name(name: str) -> HeuristicMachineConfig:
    """按稳定名称查找内置配置。"""
    normalized = str(name).strip().lower()
    for config in HEURISTIC_CONFIG_PORTFOLIO:
        if config.name.lower() == normalized:
            return config
    choices = "、".join(config.name for config in HEURISTIC_CONFIG_PORTFOLIO)
    raise ValueError(f"未知启发式配置 {name}，可选 {choices}")


CONFIG_FEATURE_DIMENSION = int(LEGACY_HEURISTIC_CONFIG.vector().shape[0])


__all__ = [
    "CONFIG_FEATURE_DIMENSION",
    "CONFIG_SCHEMA_VERSION",
    "HEURISTIC_CONFIG_PORTFOLIO",
    "HeuristicMachineConfig",
    "LEGACY_HEURISTIC_CONFIG",
    "config_by_name",
]
