# CT Scheduler Heuristic 部署包

这是仅包含 Heuristic 策略的精简算法运行时，可作为调度平台的完整
`CT_ALGORITHM_ROOT` 使用。

## 内容

- `infer/`：标准 `init/update` 企业接口。
- `src/`：Heuristic 所需解析、状态机、时序、校验和实时重算运行时。
- `requirements.txt`：唯一第三方运行依赖 NumPy。

不包含 Git 历史、虚拟环境、训练数据、测试、模型、`other_alg`、Neural、
RL、MILP、SetRank、NN-SAEA 或 LoadLock Macro 实现。

## 安装

要求 Python 3.10 或更高版本：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## 配合调度平台运行

将本目录解压到平台的 `alg/`：

```text
调度平台/
  alg/
    infer/
    src/
    requirements.txt
```

然后运行：

```powershell
.\alg\.venv\Scripts\python.exe .\realtime_scheduler\server.py --open
```

也可以放在任意目录，通过环境变量指定：

```powershell
$env:CT_ALGORITHM_ROOT = "D:\path\to\alg"
python .\realtime_scheduler\server.py --open
```

标准接口只接受 `heuristic`；传入其他算法名会明确报错。
